#ifndef GPIO_APP_H
#define GPIO_APP_H

#include "config.h"

void gpio_app_init(void);

uint8_t gpio_read_pb3_button(void);
uint8_t gpio_read_pb2_position(void);

#endif