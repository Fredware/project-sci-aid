#ifndef WRIST_TORQUE_APP_H
#define WRIST_TORQUE_APP_H

#include <stdint.h>

void wrist_torque_app_init(void);
void wrist_torque_app_update(void);

uint16_t wrist_torque_app_get_adc(void);
float wrist_torque_app_get_voltage(void);
float wrist_torque_app_get_centered_voltage(void);
float wrist_torque_app_get_value(void);

#endif