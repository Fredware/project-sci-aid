#ifndef CONFIG_H
#define CONFIG_H

#include "sam.h"
#include <stdint.h>
#include <stdbool.h>

/* ============================================================
   CLOCK
   ============================================================ */

#define CPU_CLOCK_HZ                16000000u
#define SLOW_CLOCK_HZ               32768u

/* ============================================================
   MASTER INPUTS

   PB3  = shared profile push button
   PB2  = shared wrist / slave 1 position switch
   PA17 = hand open / close switch
   ============================================================ */

#define PROFILE_BUTTON_PIN          PIO_PB3
#define POSITION_SWITCH_PIN         PIO_PB2

/*
   PA17 hand switch wiring:

   T10 has R29 10k pulldown to GND.
   T12 = +3.3V.

   Correct wiring:
      T10 ---- switch ---- T12 +3.3V

   Switch open        = LOW  = hand close
   Switch closed T12  = HIGH = hand open
*/
#define HAND_SWITCH_PIN             PIO_PA17

/*
   Compatibility only:
   adc_app.c still compiles in project and expects these old names.
   We are NOT using ADC for hand anymore.
*/
#define HAND_POT_PIN                HAND_SWITCH_PIN
#define HAND_POT_ADC_CH             0u

/* ============================================================
   BOARD I2C TO SLAVES

   PA9  = SCL
   PA10 = SDA

   Slave 1 = flexion / extension = 0x20
   Slave 2 = hand open / close   = 0x21
   ============================================================ */

#define BUS_I2C_SCL                 PIO_PA9
#define BUS_I2C_SDA                 PIO_PA10

#define SLAVE1_ADDR                 0x20u
#define SLAVE2_ADDR                 0x21u

#define BUS_I2C_HZ                  20000u

#ifndef ID_FLEXCOM0
#define ID_FLEXCOM0                 19u
#endif

#ifndef FLEX_MR_OPMODE_TWI
#define FLEX_MR_OPMODE_TWI          3u
#endif

#ifndef TWI_SR_TXRDY
#define TWI_SR_TXRDY                (1u << 2)
#endif

#ifndef TWI_SR_TXCOMP
#define TWI_SR_TXCOMP               (1u << 0)
#endif

#ifndef TWI_SR_NACK
#define TWI_SR_NACK                 (1u << 8)
#endif

/* ============================================================
   MASTER WRIST ENCODER I2C

   PA12 = SCL
   PA13 = SDA
   Encoder address = 0x36
   ============================================================ */

#define WRIST_ENCODER_I2C_SCL       PIO_PA12
#define WRIST_ENCODER_I2C_SDA       PIO_PA13

#define WRIST_ENCODER_ADDRESS       0x36u
#define WRIST_ANGLE_REGISTER        0x0Eu
#define WRIST_ENCODER_COUNTS        4096.0f

#ifndef ID_FLEXCOM5
#define ID_FLEXCOM5                 24u
#endif

#ifndef TWI_MMR_MREAD
#define TWI_MMR_MREAD               (1u << 12)
#endif

/* ============================================================
   MASTER WRIST BRUSHED MOTOR

   PA22 = IN1
   PA24 = IN2
   ============================================================ */

#define WRIST_BR_IN1_PIN            PIO_PA22
#define WRIST_BR_IN2_PIN            PIO_PA24

#define WRIST_BR_DIR_STOP           0u
#define WRIST_BR_DIR_FORWARD        1u
#define WRIST_BR_DIR_REVERSE        2u

/* ============================================================
   MASTER WRIST TORQUE SENSOR

   Example:
   PA18 = ADC channel 1

   Mid voltage:
   1.65 V = zero torque
   Above 1.65 V = one torque direction
   Below 1.65 V = other torque direction

   No software filter.
   No slew limit.
   No torque output limit.
   Hardware op-amp already handles gain/filter.
   ============================================================ */

#define WRIST_TORQUE_ADC_PIN          PIO_PB1
#define WRIST_TORQUE_ADC_CH           5u

#define WRIST_TORQUE_ADC_REF_VOLTAGE  3.30f
#define WRIST_TORQUE_ADC_MAX_COUNT    4095.0f

#define WRIST_TORQUE_MID_VOLTAGE      0.05f
#define WRIST_TORQUE_DEADBAND_VOLT    0.005f
#define WRIST_TORQUE_SCALE            0.10f

/*
   Torque gain for wrist.
   Start low first.
*/
#define WRIST_PID_KT                  0.0f

/*
   If torque helps wrong direction, change this to -1.
*/
#define WRIST_TORQUE_SIGN             1

/* ============================================================
   WRIST PROFILE TARGETS

   Your calibrated positions:
   Position 0 = 102.22 degrees
   Position 1 = 302.17 degrees
   ============================================================ */

#define WRIST_P0_POS0_DEG           102.22f
#define WRIST_P0_POS1_DEG           302.17f

#define WRIST_P1_POS0_DEG           82.22f
#define WRIST_P1_POS1_DEG           202.17f

#define WRIST_P2_POS0_DEG           602.22f
#define WRIST_P2_POS1_DEG           102.17f

/* ============================================================
   WRIST PID SETTINGS
   ============================================================ */

#define WRIST_PID_KP                3.0f
#define WRIST_PID_KI                0.0f
#define WRIST_PID_KD                0.0f

#define WRIST_PID_DEADBAND_DEG      2.0f

#define WRIST_PID_MAX_PWM_PERCENT   60.0f
#define WRIST_PID_MIN_PWM_PERCENT   25.0f

/*
   If wrist moves away from target, change this from 1 to -1.
*/
#define WRIST_PID_MOTOR_SIGN        1

/* ============================================================
   COMMAND DEFINITIONS
   ============================================================ */

#define NUM_PROFILES                3u

#define POS_A                       0u
#define POS_B                       1u

#define HAND_OPEN                   0u
#define HAND_CLOSE                  1u
#define HAND_STOP                   2u

#define MASTER_SEND_PERIOD_MS       100u

#endif