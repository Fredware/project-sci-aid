#include "sam.h"
#include <stdint.h>

#include "config.h"
#include "wrist_torque_app.h"
#include "debug_vars.h"

/*
   MASTER WRIST TORQUE SENSOR

   Simple torque reading:

      voltage = adc * 3.3 / 4095

      centered_voltage = voltage - WRIST_TORQUE_MID_VOLTAGE

      if centered voltage is inside deadband:
          torque_value = 0

      else:
          torque_value = centered_voltage * WRIST_TORQUE_SCALE

   No software filter.
   No slew limit.
   No torque output limit.
*/

static uint16_t wrist_torque_adc = 0u;
static float wrist_torque_voltage = 0.0f;
static float wrist_torque_centered_voltage = 0.0f;
static float wrist_torque_value = 0.0f;

static uint16_t wrist_torque_adc_read_one(void)
{
    ADC->ADC_CHER = (1u << WRIST_TORQUE_ADC_CH);
    ADC->ADC_CR = ADC_CR_START;

    while ((ADC->ADC_ISR & (1u << WRIST_TORQUE_ADC_CH)) == 0u)
    {
        /* wait */
    }

    return (uint16_t)(ADC->ADC_CDR[WRIST_TORQUE_ADC_CH] & 0x0FFFu);
}

static uint16_t wrist_torque_adc_read_avg(void)
{
    uint32_t sum;

    sum = 0u;

    for (uint8_t i = 0u; i < 16u; i++)
    {
        sum += wrist_torque_adc_read_one();
    }

    return (uint16_t)(sum / 16u);
}

void wrist_torque_app_init(void)
{
    PMC->PMC_PCER0 |= (1u << ID_ADC);
    PMC->PMC_PCER0 |= (1u << ID_PIOA);

    /*
       Wrist torque input pin.
       Example: PA18 / ADC channel 1.
    */
    PIOA->PIO_ODR = WRIST_TORQUE_ADC_PIN;
    PIOA->PIO_PDR = WRIST_TORQUE_ADC_PIN;

    ADC->ADC_CR = ADC_CR_SWRST;

    ADC->ADC_MR =
        ADC_MR_PRESCAL(15) |
        ADC_MR_STARTUP_SUT64 |
        ADC_MR_TRACKTIM(15);

    ADC->ADC_CHER = (1u << WRIST_TORQUE_ADC_CH);

    wrist_torque_adc = 0u;
    wrist_torque_voltage = 0.0f;
    wrist_torque_centered_voltage = 0.0f;
    wrist_torque_value = 0.0f;

    dbg_wrist_torque_adc = 0u;
    dbg_wrist_torque_voltage = 0.0f;
    dbg_wrist_torque_centered_voltage = 0.0f;
    dbg_wrist_torque_value = 0.0f;
}

void wrist_torque_app_update(void)
{
    float centered;

    wrist_torque_adc = wrist_torque_adc_read_avg();

    wrist_torque_voltage =
        ((float)wrist_torque_adc * WRIST_TORQUE_ADC_REF_VOLTAGE) /
        WRIST_TORQUE_ADC_MAX_COUNT;

    centered = wrist_torque_voltage - WRIST_TORQUE_MID_VOLTAGE;

    if ((centered < WRIST_TORQUE_DEADBAND_VOLT) &&
        (centered > -WRIST_TORQUE_DEADBAND_VOLT))
    {
        centered = 0.0f;
    }

    wrist_torque_centered_voltage = centered;
    wrist_torque_value = wrist_torque_centered_voltage * WRIST_TORQUE_SCALE;

    dbg_wrist_torque_adc = wrist_torque_adc;
    dbg_wrist_torque_voltage = wrist_torque_voltage;
    dbg_wrist_torque_centered_voltage = wrist_torque_centered_voltage;
    dbg_wrist_torque_value = wrist_torque_value;

    breakpoint_after_wrist_torque_update();
}

uint16_t wrist_torque_app_get_adc(void)
{
    return wrist_torque_adc;
}

float wrist_torque_app_get_voltage(void)
{
    return wrist_torque_voltage;
}

float wrist_torque_app_get_centered_voltage(void)
{
    return wrist_torque_centered_voltage;
}

float wrist_torque_app_get_value(void)
{
    return wrist_torque_value;
}