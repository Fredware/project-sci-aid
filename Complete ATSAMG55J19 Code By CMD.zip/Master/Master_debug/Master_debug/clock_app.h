#ifndef CLOCK_APP_H
#define CLOCK_APP_H

#include <stdint.h>

void clock_app_init(void);
uint32_t clock_app_get_cpu_hz(void);

#endif