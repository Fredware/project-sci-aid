#include "sam.h"
#include "clock_app.h"
#include "config.h"
#include "debug_vars.h"

/*
   Clean register-level clock setup.

   No ASF.
   No sysclk.
   No SystemCoreClock.

   Goal:
   - Use internal 16 MHz RC as main CPU clock
   - Enable external 32.768 kHz crystal for slow clock
*/

/* ---------- Fallback definitions if missing from header ---------- */

#ifndef CKGR_MOR_KEY_PASSWD
#define CKGR_MOR_KEY_PASSWD                 (0x37u << 16)
#endif

#ifndef CKGR_MOR_MOSCRCEN
#define CKGR_MOR_MOSCRCEN                   (1u << 3)
#endif

#ifndef CKGR_MOR_MOSCRCF_Pos
#define CKGR_MOR_MOSCRCF_Pos                4
#endif

#ifndef CKGR_MOR_MOSCRCF_Msk
#define CKGR_MOR_MOSCRCF_Msk                (7u << CKGR_MOR_MOSCRCF_Pos)
#endif

#ifndef CKGR_MOR_MOSCRCF_16_MHz
#define CKGR_MOR_MOSCRCF_16_MHz             (1u << CKGR_MOR_MOSCRCF_Pos)
#endif

#ifndef PMC_SR_MOSCRCS
#define PMC_SR_MOSCRCS                      (1u << 17)
#endif

#ifndef PMC_MCKR_CSS_MAIN_CLK
#define PMC_MCKR_CSS_MAIN_CLK               (1u << 0)
#endif

#ifndef PMC_MCKR_PRES_CLK_1
#define PMC_MCKR_PRES_CLK_1                 (0u << 4)
#endif

#ifndef PMC_SR_MCKRDY
#define PMC_SR_MCKRDY                       (1u << 3)
#endif

#ifndef SUPC_CR_KEY_PASSWD
#define SUPC_CR_KEY_PASSWD                  (0xA5u << 24)
#endif

#ifndef SUPC_CR_XTALSEL_CRYSTAL_SEL
#define SUPC_CR_XTALSEL_CRYSTAL_SEL         (1u << 3)
#endif

#ifndef SUPC_SR_OSCSEL
#define SUPC_SR_OSCSEL                      (1u << 7)
#endif

static void slow_clock_32k_xtal_init(void)
{
    SUPC->SUPC_CR = SUPC_CR_KEY_PASSWD | SUPC_CR_XTALSEL_CRYSTAL_SEL;

    while ((SUPC->SUPC_SR & SUPC_SR_OSCSEL) == 0u)
    {
        /* wait for external slow clock selection */
    }

    dbg_slow_clock_enabled = 1u;
    dbg_SUPC_SR = SUPC->SUPC_SR;
}

static void main_clock_16mhz_rc_init(void)
{
    uint32_t mor;

    mor = CKGR_MOR_KEY_PASSWD |
          CKGR_MOR_MOSCRCEN |
          CKGR_MOR_MOSCRCF_16_MHz;

    PMC->CKGR_MOR = mor;

    while ((PMC->PMC_SR & PMC_SR_MOSCRCS) == 0u)
    {
        /* wait for internal RC oscillator stable */
    }

    PMC->PMC_MCKR = PMC_MCKR_CSS_MAIN_CLK | PMC_MCKR_PRES_CLK_1;

    while ((PMC->PMC_SR & PMC_SR_MCKRDY) == 0u)
    {
        /* wait for master clock ready */
    }
}

void clock_app_init(void)
{
    slow_clock_32k_xtal_init();

    main_clock_16mhz_rc_init();

    dbg_cpu_clock_hz = CPU_CLOCK_HZ;
    dbg_clock_ok = 1u;

    dbg_PMC_MCKR = PMC->PMC_MCKR;
    dbg_CKGR_MOR = PMC->CKGR_MOR;
    dbg_PMC_SR = PMC->PMC_SR;
    dbg_SUPC_SR = SUPC->SUPC_SR;
}

uint32_t clock_app_get_cpu_hz(void)
{
    return CPU_CLOCK_HZ;
}