#include "sam.h"

#include "config.h"
#include "clock_app.h"
#include "delay_app.h"
#include "wrist_encoder_app.h"
#include "wrist_torque_app.h"
#include "wrist_brushed_app.h"
#include "wrist_pid_app.h"
#include "debug_vars.h"

/*
   MASTER

   PB3  = shared profile button
   PB2  = shared wrist / slave 1 position switch
   PA17 = hand open / close switch using old POT_A circuit

   Hardware:
      T10 has R29 10k pulldown to GND.
      T12 = +3.3V.

   Wiring:
      T10 ---- switch ---- T12 +3.3V

   Result:
      Switch open        = T10 LOW  = HAND_CLOSE
      Switch closed T12  = T10 HIGH = HAND_OPEN

   Wrist:
      - Wrist encoder
      - Wrist torque sensor
      - Wrist PID
      - Wrist brushed motor

   Slave 1:
      cmd_s1 = profile * 2 + position

   Slave 2:
      cmd_s2 = profile * 3 + hand_cmd
*/

static uint8_t active_profile = 0u;
static uint8_t last_pb3_pressed = 0u;
static uint32_t last_pb3_change_ms = 0u;

static uint32_t last_send_ms = 0u;

/* ============================================================
   INPUT INIT
   ============================================================ */

static void master_inputs_init(void)
{
    PMC->PMC_PCER0 |= (1u << ID_PIOA);
    PMC->PMC_PCER0 |= (1u << ID_PIOB);

    /*
       PB3 = profile push button
       Active LOW
    */
    PIOB->PIO_PER = PROFILE_BUTTON_PIN;
    PIOB->PIO_ODR = PROFILE_BUTTON_PIN;
    PIOB->PIO_PUER = PROFILE_BUTTON_PIN;

    /*
       PB2 = position switch
       LOW = position A
       HIGH/open = position B
    */
    PIOB->PIO_PER = POSITION_SWITCH_PIN;
    PIOB->PIO_ODR = POSITION_SWITCH_PIN;
    PIOB->PIO_PUER = POSITION_SWITCH_PIN;

    /*
       PA17 = hand switch through T10.

       IMPORTANT:
       Do NOT enable internal pull-up here.
       Your board already has R29 10k pulldown to GND.

       T10 open          = LOW  = HAND_CLOSE
       T10 connected T12 = HIGH = HAND_OPEN
    */
    PIOA->PIO_PER = HAND_SWITCH_PIN;
    PIOA->PIO_ODR = HAND_SWITCH_PIN;
    PIOA->PIO_PUDR = HAND_SWITCH_PIN;
}

/* ============================================================
   PROFILE BUTTON
   ============================================================ */

static void update_profile_button(void)
{
    uint8_t raw;
    uint8_t pressed;

    raw = ((PIOB->PIO_PDSR & PROFILE_BUTTON_PIN) != 0u) ? 1u : 0u;
    pressed = (raw == 0u) ? 1u : 0u;

    dbg_pb3_raw = raw;
    dbg_pb3_pressed = pressed;

    if (pressed != last_pb3_pressed)
    {
        if ((dbg_ms - last_pb3_change_ms) >= 50u)
        {
            last_pb3_change_ms = dbg_ms;

            if ((pressed == 1u) && (last_pb3_pressed == 0u))
            {
                active_profile++;

                if (active_profile >= NUM_PROFILES)
                {
                    active_profile = 0u;
                }

                dbg_profile_press_count++;
            }

            last_pb3_pressed = pressed;
        }
    }

    dbg_active_profile = active_profile;
}

/* ============================================================
   POSITION SWITCH
   ============================================================ */

static uint8_t read_position_switch(void)
{
    uint8_t raw;

    raw = ((PIOB->PIO_PDSR & POSITION_SWITCH_PIN) != 0u) ? 1u : 0u;

    dbg_pb2_raw = raw;

    if (raw == 0u)
    {
        dbg_active_position = POS_A;
        return POS_A;
    }

    dbg_active_position = POS_B;
    return POS_B;
}

/* ============================================================
   HAND SWITCH

   PA17 / T10 LOW  = HAND_CLOSE
   PA17 / T10 HIGH = HAND_OPEN

   T10 ---- switch ---- T12 +3.3V

   No ADC.
   No pot.
   ============================================================ */

static void update_hand_switch_command(void)
{
    uint8_t raw;

    raw = ((PIOA->PIO_PDSR & HAND_SWITCH_PIN) != 0u) ? 1u : 0u;

    /*
       Reuse old debug variables for Watch window.
    */
    dbg_hand_pot_adc = raw;
    dbg_hand_pot_delta_adc = raw;
    dbg_hand_pot_voltage = raw ? 3.30f : 0.0f;

    if (raw == 1u)
    {
        dbg_active_hand_cmd = HAND_OPEN;
        dbg_active_hand_power = 100u;
    }
    else
    {
        dbg_active_hand_cmd = HAND_CLOSE;
        dbg_active_hand_power = 100u;
    }
}

/* ============================================================
   I2C MASTER TO SLAVES
   ============================================================ */

static void bus_i2c_master_init(void)
{
    uint32_t cldiv;

    PMC->PMC_PCER0 |= (1u << ID_PIOA);
    PMC->PMC_PCER0 |= (1u << ID_FLEXCOM0);

    PIOA->PIO_PDR = BUS_I2C_SCL | BUS_I2C_SDA;

    PIOA->PIO_ABCDSR[0] &= ~(BUS_I2C_SCL | BUS_I2C_SDA);
    PIOA->PIO_ABCDSR[1] &= ~(BUS_I2C_SCL | BUS_I2C_SDA);

    PIOA->PIO_PUER = BUS_I2C_SCL | BUS_I2C_SDA;

    FLEXCOM0->FLEXCOM_MR = FLEX_MR_OPMODE_TWI;

    TWI0->TWI_CR = TWI_CR_SWRST;
    TWI0->TWI_CR = TWI_CR_MSEN | TWI_CR_SVDIS;

    cldiv = ((CPU_CLOCK_HZ / BUS_I2C_HZ) - 4u) / 2u;

    TWI0->TWI_CWGR = (cldiv << 0) | (cldiv << 8);
}

static uint8_t bus_twi_wait(uint32_t mask)
{
    uint32_t timeout;

    timeout = 300000u;

    while (1)
    {
        uint32_t sr;

        sr = TWI0->TWI_SR;
        dbg_last_twi0_sr = sr;

        if ((sr & TWI_SR_NACK) != 0u)
        {
            TWI0->TWI_CR = TWI_CR_STOP;
            return 0u;
        }

        if ((sr & mask) != 0u)
        {
            return 1u;
        }

        if (--timeout == 0u)
        {
            TWI0->TWI_CR = TWI_CR_STOP;
            return 0u;
        }
    }
}

static uint8_t send_onebyte_command(uint8_t slave_addr, uint8_t cmd)
{
    dbg_last_error_code = 0u;

    TWI0->TWI_CR = TWI_CR_MSEN | TWI_CR_SVDIS;
    TWI0->TWI_MMR = ((uint32_t)slave_addr << 16);

    if (!bus_twi_wait(TWI_SR_TXRDY))
    {
        dbg_last_error_code = 2u;
        return 0u;
    }

    TWI0->TWI_THR = cmd;

    if (!bus_twi_wait(TWI_SR_TXRDY))
    {
        dbg_last_error_code = 3u;
        return 0u;
    }

    TWI0->TWI_CR = TWI_CR_STOP;

    if (!bus_twi_wait(TWI_SR_TXCOMP))
    {
        dbg_last_error_code = 4u;
        return 0u;
    }

    return 1u;
}

static void send_commands_to_slaves(void)
{
    uint8_t position;
    uint8_t cmd_s1;
    uint8_t cmd_s2;
    uint8_t s1_ok;
    uint8_t s2_ok;

    position = dbg_active_position;

    /*
       Slave 1:
       profile + position
    */
    cmd_s1 = (uint8_t)((active_profile * 2u) + position);

    /*
       Slave 2:
       profile + hand command
    */
    cmd_s2 = (uint8_t)((active_profile * 3u) + dbg_active_hand_cmd);

    dbg_last_cmd_s1 = cmd_s1;
    dbg_last_cmd_s2 = cmd_s2;

    breakpoint_before_send();

    s1_ok = send_onebyte_command(SLAVE1_ADDR, cmd_s1);
    s2_ok = send_onebyte_command(SLAVE2_ADDR, cmd_s2);

    dbg_last_s1_ok = s1_ok;
    dbg_last_s2_ok = s2_ok;

    if (s1_ok)
    {
        dbg_s1_ok_count++;
    }
    else
    {
        dbg_s1_fail_count++;
    }

    if (s2_ok)
    {
        dbg_s2_ok_count++;
    }
    else
    {
        dbg_s2_fail_count++;
    }

    dbg_send_count++;

    breakpoint_after_send();
}

/* ============================================================
   MAIN
   ============================================================ */

int main(void)
{
    SystemInit();
    WDT->WDT_MR = WDT_MR_WDDIS;

    clock_app_init();

    wrist_brushed_app_init();

    delay_app_init_1ms();

    master_inputs_init();

    bus_i2c_master_init();

    wrist_encoder_app_init();

    wrist_torque_app_init();

    wrist_pid_app_init();

    while (1)
    {
        dbg_master_loop_count++;

        update_profile_button();

        read_position_switch();

        update_hand_switch_command();

        wrist_encoder_app_update();

        wrist_torque_app_update();

        wrist_pid_app_update();

        breakpoint_after_inputs();

        if ((dbg_ms - last_send_ms) >= MASTER_SEND_PERIOD_MS)
        {
            last_send_ms = dbg_ms;
            send_commands_to_slaves();
        }

        delay_ms(10u);
    }
}