#include "sam.h"
#include "delay_app.h"
#include "clock_app.h"
#include "debug_vars.h"
#include "wrist_brushed_app.h"

void SysTick_Handler(void)
{
    dbg_ms++;

    /*
       Wrist brushed motor software PWM tick.
    */
    wrist_brushed_pwm_tick_1ms();
}

void delay_app_init_1ms(void)
{
    uint32_t ticks;

    ticks = clock_app_get_cpu_hz() / 1000u;

    SysTick->LOAD = ticks - 1u;
    SysTick->VAL = 0u;

    SysTick->CTRL = SysTick_CTRL_CLKSOURCE_Msk |
                    SysTick_CTRL_TICKINT_Msk |
                    SysTick_CTRL_ENABLE_Msk;
}

void delay_ms(uint32_t ms)
{
    uint32_t start;

    start = dbg_ms;

    while ((dbg_ms - start) < ms)
    {
        __NOP();
    }
}