#include "sam.h"
#include "adc_app.h"
#include "config.h"

/*
   PA17 = hand pot
   ADC channel = AD0
*/

static void adc_disable_all_channels(void)
{
    ADC->ADC_CHDR = 0xFFFFFFFFu;
}

void adc_app_init(void)
{
    PMC->PMC_PCER0 |= (1u << ID_ADC);

    /* PA17 pot input to ADC */
    PIOA->PIO_ODR = HAND_POT_PIN;  /* input */
    PIOA->PIO_PDR = HAND_POT_PIN;  /* peripheral/ADC control */

    ADC->ADC_CR = ADC_CR_SWRST;

    ADC->ADC_MR =
        ADC_MR_PRESCAL(15) |
        ADC_MR_STARTUP_SUT64 |
        ADC_MR_TRACKTIM(15);

    adc_disable_all_channels();

    ADC->ADC_CHER = (1u << HAND_POT_ADC_CH);
}

uint16_t adc_read(uint8_t ch)
{
    uint32_t mask;
    uint16_t value;

    mask = (1u << ch);

    adc_disable_all_channels();
    ADC->ADC_CHER = mask;

    /*
       Throw away first reading after channel switch.
       This matches the safe style from your working ADC file.
    */
    ADC->ADC_CR = ADC_CR_START;
    while ((ADC->ADC_ISR & mask) == 0u)
    {
    }
    value = (uint16_t)(ADC->ADC_CDR[ch] & 0x03FFu);

    /* Real reading */
    ADC->ADC_CR = ADC_CR_START;
    while ((ADC->ADC_ISR & mask) == 0u)
    {
    }
    value = (uint16_t)(ADC->ADC_CDR[ch] & 0x03FFu);

    return value;
}

uint16_t adc_read_hand_pot(void)
{
    return adc_read(HAND_POT_ADC_CH);
}