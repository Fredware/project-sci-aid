#ifndef I2C_MASTER_APP_H
#define I2C_MASTER_APP_H

#include "config.h"

void i2c_master_app_init(void);

uint8_t i2c_master_send_onebyte(uint8_t slave_addr, uint8_t cmd);

#endif