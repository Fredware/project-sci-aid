#include "sam.h"
#include "gpio_app.h"
#include "config.h"

/*
   Master inputs:

   PB3 = push button / profile button
   PB2 = position switch

   Both are GPIO inputs with internal pull-up.
   Press/switch to GND = 0
   Open = 1
*/

static void piob_input_pullup(uint32_t pin)
{
    PIOB->PIO_PER = pin;    /* GPIO control */
    PIOB->PIO_ODR = pin;    /* input */
    PIOB->PIO_PUER = pin;   /* pull-up */
}

void gpio_app_init(void)
{
    PMC->PMC_PCER0 |= (1u << ID_PIOA);
    PMC->PMC_PCER0 |= (1u << ID_PIOB);

    piob_input_pullup(PROFILE_BUTTON_PIN);   /* PB3 */
    piob_input_pullup(POSITION_SWITCH_PIN);  /* PB2 */
}

uint8_t gpio_read_pb3_button(void)
{
    if ((PIOB->PIO_PDSR & PROFILE_BUTTON_PIN) != 0u)
    {
        return 1u;
    }

    return 0u;
}

uint8_t gpio_read_pb2_position(void)
{
    if ((PIOB->PIO_PDSR & POSITION_SWITCH_PIN) != 0u)
    {
        return 1u;
    }

    return 0u;
}