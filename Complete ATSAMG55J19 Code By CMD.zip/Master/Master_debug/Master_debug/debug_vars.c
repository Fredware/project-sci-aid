#include "sam.h"
#include "debug_vars.h"

/* Clock */
volatile uint32_t dbg_cpu_clock_hz = 0u;
volatile uint32_t dbg_clock_ok = 0u;
volatile uint32_t dbg_slow_clock_enabled = 0u;

volatile uint32_t dbg_PMC_MCKR = 0u;
volatile uint32_t dbg_CKGR_MOR = 0u;
volatile uint32_t dbg_PMC_SR = 0u;
volatile uint32_t dbg_SUPC_SR = 0u;

volatile uint32_t dbg_ms = 0u;

/* Master inputs */
volatile uint32_t dbg_master_loop_count = 0u;

volatile uint8_t  dbg_pb3_raw = 1u;
volatile uint8_t  dbg_pb3_pressed = 0u;
volatile uint32_t dbg_profile_press_count = 0u;
volatile uint8_t  dbg_active_profile = 0u;

volatile uint8_t  dbg_pb2_raw = 1u;
volatile uint8_t  dbg_active_position = 1u;

volatile uint16_t dbg_hand_pot_adc = 0u;
volatile float    dbg_hand_pot_voltage = 0.0f;
volatile int32_t  dbg_hand_pot_delta_adc = 0;
volatile uint8_t  dbg_active_hand_cmd = 2u;
volatile uint8_t  dbg_active_hand_power = 0u;

/* Slave command debug */
volatile uint8_t  dbg_last_cmd_s1 = 0u;
volatile uint8_t  dbg_last_cmd_s2 = 0u;

volatile uint32_t dbg_send_count = 0u;

volatile uint32_t dbg_s1_ok_count = 0u;
volatile uint32_t dbg_s1_fail_count = 0u;
volatile uint8_t  dbg_last_s1_ok = 0u;

volatile uint32_t dbg_s2_ok_count = 0u;
volatile uint32_t dbg_s2_fail_count = 0u;
volatile uint8_t  dbg_last_s2_ok = 0u;

volatile uint32_t dbg_last_error_code = 0u;
volatile uint32_t dbg_last_twi0_sr = 0u;

/* Wrist encoder */
volatile uint16_t dbg_wrist_encoder_raw = 0u;
volatile float    dbg_wrist_deg_360 = 0.0f;
volatile uint32_t dbg_wrist_encoder_read_count = 0u;
volatile uint8_t  dbg_wrist_encoder_ok = 0u;
volatile uint32_t dbg_last_twi5_sr = 0u;

/* Wrist brushed motor */
volatile uint8_t  dbg_wrist_br_direction = 0u;
volatile uint8_t  dbg_wrist_br_enabled = 0u;
volatile uint32_t dbg_wrist_br_duty_percent = 0u;
volatile uint32_t dbg_wrist_br_accumulator = 0u;

/* Wrist torque sensor */
volatile uint16_t dbg_wrist_torque_adc = 0u;
volatile float    dbg_wrist_torque_voltage = 0.0f;
volatile float    dbg_wrist_torque_centered_voltage = 0.0f;
volatile float    dbg_wrist_torque_value = 0.0f;

/* Wrist PID */
volatile float    dbg_wrist_setpoint_deg = 0.0f;
volatile float    dbg_wrist_feedback_deg = 0.0f;
volatile float    dbg_wrist_error_deg = 0.0f;

volatile float    dbg_wrist_pid_up = 0.0f;
volatile float    dbg_wrist_pid_ui = 0.0f;
volatile float    dbg_wrist_pid_ud = 0.0f;
volatile float    dbg_wrist_pid_ut = 0.0f;

volatile float    dbg_wrist_pid_output = 0.0f;
volatile float    dbg_wrist_pid_pwm_percent = 0.0f;
volatile uint8_t  dbg_wrist_pid_direction = 0u;
volatile uint8_t  dbg_wrist_pid_active = 0u;

/* Breakpoint helpers */
void breakpoint_after_inputs(void)
{
	__NOP();
}

void breakpoint_before_send(void)
{
	__NOP();
}

void breakpoint_after_send(void)
{
	__NOP();
}

void breakpoint_after_wrist_encoder_read(void)
{
	__NOP();
}

void breakpoint_after_wrist_torque_update(void)
{
	__NOP();
}

void breakpoint_after_wrist_brushed_update(void)
{
	__NOP();
}

void breakpoint_after_wrist_pid_update(void)
{
	__NOP();
}