#ifndef WRIST_BRUSHED_APP_H
#define WRIST_BRUSHED_APP_H

#include "config.h"

void wrist_brushed_app_init(void);

void wrist_brushed_stop(void);
void wrist_brushed_forward(uint8_t percent);
void wrist_brushed_reverse(uint8_t percent);

/*
   Called by SysTick_Handler every 1 ms.
*/
void wrist_brushed_pwm_tick_1ms(void);

#endif