#include "sam.h"
#include "wrist_brushed_app.h"
#include "config.h"
#include "debug_vars.h"

/*
   MASTER WRIST BRUSHED MOTOR - DIRECT DRIVE TEST

   PA22 = IN1
   PA24 = IN2

   Forward:
      IN1 HIGH
      IN2 LOW

   Reverse:
      IN1 LOW
      IN2 HIGH

   Stop / coast:
      IN1 LOW
      IN2 LOW

   This version does NOT do software PWM.
   Purpose: confirm PID direction and motor response first.
*/

static volatile uint8_t  br_direction = WRIST_BR_DIR_STOP;
static volatile uint8_t  br_enabled = 0u;
static volatile uint32_t br_duty_percent = 0u;
static volatile uint32_t br_accumulator = 0u;

static void sync_debug(void)
{
    dbg_wrist_br_direction = br_direction;
    dbg_wrist_br_enabled = br_enabled;
    dbg_wrist_br_duty_percent = br_duty_percent;
    dbg_wrist_br_accumulator = br_accumulator;
}

static void brushed_coast(void)
{
    PIOA->PIO_CODR = WRIST_BR_IN1_PIN | WRIST_BR_IN2_PIN;
}

void wrist_brushed_stop(void)
{
    br_enabled = 0u;
    br_duty_percent = 0u;
    br_direction = WRIST_BR_DIR_STOP;
    br_accumulator = 0u;

    brushed_coast();

    sync_debug();

    breakpoint_after_wrist_brushed_update();
}

void wrist_brushed_forward(uint8_t percent)
{
    if (percent > 100u)
    {
        percent = 100u;
    }

    br_direction = WRIST_BR_DIR_FORWARD;
    br_enabled = 1u;
    br_duty_percent = percent;
    br_accumulator = 0u;

    /*
       Direct forward drive.
    */
    PIOA->PIO_SODR = WRIST_BR_IN1_PIN;
    PIOA->PIO_CODR = WRIST_BR_IN2_PIN;

    sync_debug();

    breakpoint_after_wrist_brushed_update();
}

void wrist_brushed_reverse(uint8_t percent)
{
    if (percent > 100u)
    {
        percent = 100u;
    }

    br_direction = WRIST_BR_DIR_REVERSE;
    br_enabled = 1u;
    br_duty_percent = percent;
    br_accumulator = 0u;

    /*
       Direct reverse drive.
    */
    PIOA->PIO_CODR = WRIST_BR_IN1_PIN;
    PIOA->PIO_SODR = WRIST_BR_IN2_PIN;

    sync_debug();

    breakpoint_after_wrist_brushed_update();
}

/*
   Not used in this direct-drive version.
   Keep this function so delay_app.c still builds.
*/
void wrist_brushed_pwm_tick_1ms(void)
{
    sync_debug();
}

void wrist_brushed_app_init(void)
{
    PMC->PMC_PCER0 |= (1u << ID_PIOA);

    PIOA->PIO_PER = WRIST_BR_IN1_PIN | WRIST_BR_IN2_PIN;
    PIOA->PIO_OER = WRIST_BR_IN1_PIN | WRIST_BR_IN2_PIN;

    wrist_brushed_stop();
}