#ifndef DELAY_APP_H
#define DELAY_APP_H

#include <stdint.h>

void delay_app_init_1ms(void);
void delay_ms(uint32_t ms);

#endif