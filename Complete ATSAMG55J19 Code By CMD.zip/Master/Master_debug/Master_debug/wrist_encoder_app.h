#ifndef WRIST_ENCODER_APP_H
#define WRIST_ENCODER_APP_H

#include "config.h"

void wrist_encoder_app_init(void);
void wrist_encoder_app_update(void);

uint16_t wrist_encoder_app_get_raw(void);
float wrist_encoder_app_get_deg_360(void);

#endif