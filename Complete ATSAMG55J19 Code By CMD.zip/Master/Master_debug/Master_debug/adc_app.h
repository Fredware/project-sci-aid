#ifndef ADC_APP_H
#define ADC_APP_H

#include "config.h"

void adc_app_init(void);

uint16_t adc_read(uint8_t ch);
uint16_t adc_read_hand_pot(void);

#endif