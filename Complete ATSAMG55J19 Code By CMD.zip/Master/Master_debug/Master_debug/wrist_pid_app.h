#ifndef WRIST_PID_APP_H
#define WRIST_PID_APP_H

#include "config.h"

void wrist_pid_app_init(void);
void wrist_pid_app_update(void);

float wrist_pid_app_get_setpoint(void);

#endif