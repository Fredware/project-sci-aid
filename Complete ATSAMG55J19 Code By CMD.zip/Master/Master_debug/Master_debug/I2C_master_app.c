#include "sam.h"
#include "i2c_master_app.h"
#include "config.h"
#include "debug_vars.h"

/*
   Board-to-board I2C master

   PA9  = SCL
   PA10 = SDA

   Important:
   PA9/PA10 are NOT GPIO here.
   They are assigned to TWI0 peripheral.
*/

void i2c_master_app_init(void)
{
    uint32_t cldiv;

    PMC->PMC_PCER0 |= (1u << ID_PIOA);
    PMC->PMC_PCER0 |= (1u << ID_FLEXCOM0);

    /* PA9 / PA10 to peripheral A for TWI0 */
    PIOA->PIO_PDR = BUS_I2C_SCL | BUS_I2C_SDA;

    PIOA->PIO_ABCDSR[0] &= ~(BUS_I2C_SCL | BUS_I2C_SDA);
    PIOA->PIO_ABCDSR[1] &= ~(BUS_I2C_SCL | BUS_I2C_SDA);

    /* Enable internal pullups also. External 4.7k pullups are still better. */
    PIOA->PIO_PUER = BUS_I2C_SCL | BUS_I2C_SDA;

    FLEXCOM0->FLEXCOM_MR = FLEX_MR_OPMODE_TWI;

    TWI0->TWI_CR = TWI_CR_SWRST;
    TWI0->TWI_CR = TWI_CR_MSEN | TWI_CR_SVDIS;

    /*
       CPU clock = 16 MHz.
       Slow I2C = 20 kHz for debug stability.
    */
    cldiv = ((CPU_CLOCK_HZ / BUS_I2C_HZ) - 4u) / 2u;

    TWI0->TWI_CWGR = (cldiv << 0) | (cldiv << 8);
}

static uint8_t i2c_wait(uint32_t mask)
{
    uint32_t timeout;

    timeout = 100000u;

    while (1)
    {
        uint32_t sr;

        sr = TWI0->TWI_SR;
        dbg_last_twi0_sr = sr;

        if ((sr & TWI_SR_NACK) != 0u)
        {
            TWI0->TWI_CR = TWI_CR_STOP;
            return 0u;
        }

        if ((sr & mask) != 0u)
        {
            return 1u;
        }

        if (--timeout == 0u)
        {
            return 0u;
        }
    }
}

uint8_t i2c_master_send_onebyte(uint8_t slave_addr, uint8_t cmd)
{
    dbg_last_error_code = 0u;

    TWI0->TWI_MMR = ((uint32_t)slave_addr << 16);

    if (!i2c_wait(TWI_SR_TXRDY))
    {
        dbg_last_error_code = 2u;
        return 0u;
    }

    TWI0->TWI_THR = cmd;

    if (!i2c_wait(TWI_SR_TXRDY))
    {
        dbg_last_error_code = 3u;
        return 0u;
    }

    TWI0->TWI_CR = TWI_CR_STOP;

    if (!i2c_wait(TWI_SR_TXCOMP))
    {
        dbg_last_error_code = 4u;
        return 0u;
    }

    return 1u;
}