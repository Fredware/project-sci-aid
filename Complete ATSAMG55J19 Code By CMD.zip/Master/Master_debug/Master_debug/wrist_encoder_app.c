#include "sam.h"

#include "wrist_encoder_app.h"
#include "config.h"
#include "debug_vars.h"

/*
   MASTER WRIST ENCODER

   PA12 = SCL
   PA13 = SDA

   Encoder address = 0x36
   Angle register  = 0x0E

   This version uses TWI internal address register.
   Better for 0x36 magnetic encoder register reads.
*/

#ifndef TWI_MMR_IADRSZ_1_BYTE
#define TWI_MMR_IADRSZ_1_BYTE       (1u << 8)
#endif

#ifndef TWI_MMR_MREAD
#define TWI_MMR_MREAD               (1u << 12)
#endif

static uint16_t wrist_raw = 0u;
static float wrist_deg_360 = 0.0f;

static uint8_t twi5_wait_safe(uint32_t mask)
{
    uint32_t timeout;
    uint32_t sr;

    timeout = 100000u;

    while (timeout > 0u)
    {
        sr = TWI5->TWI_SR;
        dbg_last_twi5_sr = sr;

        if ((sr & TWI_SR_NACK) != 0u)
        {
            TWI5->TWI_CR = TWI_CR_STOP;
            return 0u;
        }

        if ((sr & mask) != 0u)
        {
            return 1u;
        }

        timeout--;
    }

    TWI5->TWI_CR = TWI_CR_STOP;
    return 0u;
}

void wrist_encoder_app_init(void)
{
    uint32_t cldiv;

    PMC->PMC_PCER0 |= (1u << ID_PIOA);
    PMC->PMC_PCER0 |= (1u << ID_FLEXCOM5);

    PIOA->PIO_PDR = WRIST_ENCODER_I2C_SCL | WRIST_ENCODER_I2C_SDA;

    PIOA->PIO_ABCDSR[0] &= ~(WRIST_ENCODER_I2C_SCL | WRIST_ENCODER_I2C_SDA);
    PIOA->PIO_ABCDSR[1] &= ~(WRIST_ENCODER_I2C_SCL | WRIST_ENCODER_I2C_SDA);

    PIOA->PIO_PUER = WRIST_ENCODER_I2C_SCL | WRIST_ENCODER_I2C_SDA;

    FLEXCOM5->FLEXCOM_MR = FLEX_MR_OPMODE_TWI;

    TWI5->TWI_CR = TWI_CR_SWRST;
    TWI5->TWI_CR = TWI_CR_MSEN | TWI_CR_SVDIS;

    /*
       100 kHz for reliable encoder read.
    */
    cldiv = ((CPU_CLOCK_HZ / 100000u) - 4u) / 2u;

    TWI5->TWI_CWGR = (cldiv << 0) | (cldiv << 8);

    wrist_raw = 0u;
    wrist_deg_360 = 0.0f;

    dbg_wrist_encoder_ok = 0u;
    dbg_wrist_encoder_raw = 0u;
    dbg_wrist_deg_360 = 0.0f;
    dbg_wrist_encoder_read_count = 0u;
    dbg_last_twi5_sr = 0u;
}

void wrist_encoder_app_update(void)
{
    uint8_t high_byte;
    uint8_t low_byte;
    uint16_t raw;

    dbg_wrist_encoder_ok = 0u;

    /*
       Read 2 bytes from register 0x0E using internal address.
    */
    TWI5->TWI_CR = TWI_CR_MSEN | TWI_CR_SVDIS;

    TWI5->TWI_MMR =
        ((uint32_t)WRIST_ENCODER_ADDRESS << 16) |
        TWI_MMR_MREAD |
        TWI_MMR_IADRSZ_1_BYTE;

    TWI5->TWI_IADR = WRIST_ANGLE_REGISTER;

    TWI5->TWI_CR = TWI_CR_START;

    if (!twi5_wait_safe(TWI_SR_RXRDY))
    {
        return;
    }

    high_byte = (uint8_t)TWI5->TWI_RHR;

    /*
       For 2-byte read, send STOP before receiving last byte.
    */
    TWI5->TWI_CR = TWI_CR_STOP;

    if (!twi5_wait_safe(TWI_SR_RXRDY))
    {
        return;
    }

    low_byte = (uint8_t)TWI5->TWI_RHR;

    if (!twi5_wait_safe(TWI_SR_TXCOMP))
    {
        return;
    }

    raw = (((uint16_t)high_byte << 8) | low_byte) & 0x0FFFu;

    wrist_raw = raw;
    wrist_deg_360 = ((float)raw * 360.0f) / WRIST_ENCODER_COUNTS;

    dbg_wrist_encoder_raw = wrist_raw;
    dbg_wrist_deg_360 = wrist_deg_360;
    dbg_wrist_encoder_read_count++;
    dbg_wrist_encoder_ok = 1u;

    breakpoint_after_wrist_encoder_read();
}

uint16_t wrist_encoder_app_get_raw(void)
{
    return wrist_raw;
}

float wrist_encoder_app_get_deg_360(void)
{
    return wrist_deg_360;
}