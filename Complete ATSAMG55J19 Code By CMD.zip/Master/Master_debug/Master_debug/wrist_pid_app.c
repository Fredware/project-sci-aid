#include "sam.h"
#include "wrist_pid_app.h"
#include "config.h"
#include "debug_vars.h"
#include "wrist_encoder_app.h"
#include "wrist_brushed_app.h"
#include "wrist_torque_app.h"

/*
   MASTER WRIST PID WITH TORQUE TERM

   Position part:
      u_p = KP * error
      u_i = KI * integral
      u_d = KD * error change

   Torque part:
      u_t = KT * wrist_torque_value

   Total:
      output = u_p + u_i + u_d + u_t

   No torque filter.
   No torque slew limit.
   No torque output limit.

   Final motor PWM is still limited by WRIST_PID_MAX_PWM_PERCENT.
*/

static float integral = 0.0f;
static float error_prev = 0.0f;

static float wrap360(float angle)
{
    while (angle >= 360.0f)
    {
        angle -= 360.0f;
    }

    while (angle < 0.0f)
    {
        angle += 360.0f;
    }

    return angle;
}

static float circular_error(float target, float actual)
{
    float error;

    error = target - actual;

    while (error > 180.0f)
    {
        error -= 360.0f;
    }

    while (error < -180.0f)
    {
        error += 360.0f;
    }

    return error;
}

static float clamp_float(float x, float min_val, float max_val)
{
    if (x > max_val)
    {
        return max_val;
    }

    if (x < min_val)
    {
        return min_val;
    }

    return x;
}

static float abs_float(float x)
{
    if (x < 0.0f)
    {
        return -x;
    }

    return x;
}

static float get_setpoint_from_profile_position(void)
{
    uint8_t profile;
    uint8_t position;

    profile = dbg_active_profile;
    position = dbg_active_position;

    if (profile == 0u)
    {
        if (position == POS_A)
        {
            return wrap360(WRIST_P0_POS0_DEG);
        }
        else
        {
            return wrap360(WRIST_P0_POS1_DEG);
        }
    }
    else if (profile == 1u)
    {
        if (position == POS_A)
        {
            return wrap360(WRIST_P1_POS0_DEG);
        }
        else
        {
            return wrap360(WRIST_P1_POS1_DEG);
        }
    }
    else
    {
        if (position == POS_A)
        {
            return wrap360(WRIST_P2_POS0_DEG);
        }
        else
        {
            return wrap360(WRIST_P2_POS1_DEG);
        }
    }
}

void wrist_pid_app_init(void)
{
    integral = 0.0f;
    error_prev = 0.0f;

    dbg_wrist_setpoint_deg = 0.0f;
    dbg_wrist_feedback_deg = 0.0f;
    dbg_wrist_error_deg = 0.0f;

    dbg_wrist_pid_up = 0.0f;
    dbg_wrist_pid_ui = 0.0f;
    dbg_wrist_pid_ud = 0.0f;
    dbg_wrist_pid_ut = 0.0f;

    dbg_wrist_pid_output = 0.0f;
    dbg_wrist_pid_pwm_percent = 0.0f;
    dbg_wrist_pid_direction = 0u;
    dbg_wrist_pid_active = 0u;

    wrist_brushed_stop();
}

float wrist_pid_app_get_setpoint(void)
{
    return get_setpoint_from_profile_position();
}

void wrist_pid_app_update(void)
{
    float setpoint;
    float feedback;
    float error;

    float u_p;
    float u_i;
    float u_d;
    float u_t;

    float torque_value;

    float output;
    float pwm_percent;

    /*
       If encoder read failed, do not run PID.
       This prevents motor from running from stale / bad encoder data.
    */
    if (dbg_wrist_encoder_ok == 0u)
    {
        integral = 0.0f;
        error_prev = 0.0f;

        dbg_wrist_pid_up = 0.0f;
        dbg_wrist_pid_ui = 0.0f;
        dbg_wrist_pid_ud = 0.0f;
        dbg_wrist_pid_ut = 0.0f;

        dbg_wrist_pid_active = 0u;
        dbg_wrist_pid_pwm_percent = 0.0f;
        dbg_wrist_pid_direction = 0u;
        dbg_wrist_pid_output = 0.0f;

        wrist_brushed_stop();

        breakpoint_after_wrist_pid_update();
        return;
    }

    setpoint = get_setpoint_from_profile_position();
    feedback = wrist_encoder_app_get_deg_360();

    error = circular_error(setpoint, feedback);

    dbg_wrist_setpoint_deg = setpoint;
    dbg_wrist_feedback_deg = feedback;
    dbg_wrist_error_deg = error;

    /*
       Deadband stop.
       Torque term is also zero here for safety.
    */
    if (abs_float(error) <= WRIST_PID_DEADBAND_DEG)
    {
        integral = 0.0f;
        error_prev = error;

        dbg_wrist_pid_up = 0.0f;
        dbg_wrist_pid_ui = 0.0f;
        dbg_wrist_pid_ud = 0.0f;
        dbg_wrist_pid_ut = 0.0f;

        dbg_wrist_pid_output = 0.0f;
        dbg_wrist_pid_pwm_percent = 0.0f;
        dbg_wrist_pid_direction = 0u;
        dbg_wrist_pid_active = 0u;

        wrist_brushed_stop();

        breakpoint_after_wrist_pid_update();
        return;
    }

    /*
       Position PID.
    */
    u_p = WRIST_PID_KP * error;

    integral += error;
    u_i = WRIST_PID_KI * integral;

    u_d = WRIST_PID_KD * (error - error_prev);

    error_prev = error;

    /*
       Torque term.
       wrist_torque_app_get_value() is centered around zero.
    */
    torque_value = wrist_torque_app_get_value();

    u_t = WRIST_PID_KT * torque_value * (float)WRIST_TORQUE_SIGN;

    /*
       Total output.
    */
    output = u_p + u_i + u_d + u_t;

    /*
       If motor direction is wrong overall, flip WRIST_PID_MOTOR_SIGN.
    */
    output = output * (float)WRIST_PID_MOTOR_SIGN;

    /*
       Final motor PWM safety limit.
    */
    output = clamp_float(output,
                         -WRIST_PID_MAX_PWM_PERCENT,
                         WRIST_PID_MAX_PWM_PERCENT);

    pwm_percent = abs_float(output);

    if (pwm_percent < WRIST_PID_MIN_PWM_PERCENT)
    {
        pwm_percent = WRIST_PID_MIN_PWM_PERCENT;
    }

    dbg_wrist_pid_up = u_p;
    dbg_wrist_pid_ui = u_i;
    dbg_wrist_pid_ud = u_d;
    dbg_wrist_pid_ut = u_t;

    dbg_wrist_pid_output = output;
    dbg_wrist_pid_pwm_percent = pwm_percent;
    dbg_wrist_pid_active = 1u;

    if (output > 0.0f)
    {
        dbg_wrist_pid_direction = 1u;
        wrist_brushed_forward((uint8_t)pwm_percent);
    }
    else
    {
        dbg_wrist_pid_direction = 2u;
        wrist_brushed_reverse((uint8_t)pwm_percent);
    }

    breakpoint_after_wrist_pid_update();
}