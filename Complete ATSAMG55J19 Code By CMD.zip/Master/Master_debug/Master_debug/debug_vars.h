#ifndef DEBUG_VARS_H
#define DEBUG_VARS_H

#include <stdint.h>

/* Clock */
extern volatile uint32_t dbg_cpu_clock_hz;
extern volatile uint32_t dbg_clock_ok;
extern volatile uint32_t dbg_slow_clock_enabled;

extern volatile uint32_t dbg_PMC_MCKR;
extern volatile uint32_t dbg_CKGR_MOR;
extern volatile uint32_t dbg_PMC_SR;
extern volatile uint32_t dbg_SUPC_SR;

extern volatile uint32_t dbg_ms;

/* Master inputs */
extern volatile uint32_t dbg_master_loop_count;

extern volatile uint8_t  dbg_pb3_raw;
extern volatile uint8_t  dbg_pb3_pressed;
extern volatile uint32_t dbg_profile_press_count;
extern volatile uint8_t  dbg_active_profile;

extern volatile uint8_t  dbg_pb2_raw;
extern volatile uint8_t  dbg_active_position;

extern volatile uint16_t dbg_hand_pot_adc;
extern volatile float    dbg_hand_pot_voltage;
extern volatile int32_t  dbg_hand_pot_delta_adc;
extern volatile uint8_t  dbg_active_hand_cmd;
extern volatile uint8_t  dbg_active_hand_power;

/* Slave command debug */
extern volatile uint8_t  dbg_last_cmd_s1;
extern volatile uint8_t  dbg_last_cmd_s2;

extern volatile uint32_t dbg_send_count;

extern volatile uint32_t dbg_s1_ok_count;
extern volatile uint32_t dbg_s1_fail_count;
extern volatile uint8_t  dbg_last_s1_ok;

extern volatile uint32_t dbg_s2_ok_count;
extern volatile uint32_t dbg_s2_fail_count;
extern volatile uint8_t  dbg_last_s2_ok;

extern volatile uint32_t dbg_last_error_code;
extern volatile uint32_t dbg_last_twi0_sr;

/* Wrist encoder */
extern volatile uint16_t dbg_wrist_encoder_raw;
extern volatile float    dbg_wrist_deg_360;
extern volatile uint32_t dbg_wrist_encoder_read_count;
extern volatile uint8_t  dbg_wrist_encoder_ok;
extern volatile uint32_t dbg_last_twi5_sr;

/* Wrist brushed motor */
extern volatile uint8_t  dbg_wrist_br_direction;
extern volatile uint8_t  dbg_wrist_br_enabled;
extern volatile uint32_t dbg_wrist_br_duty_percent;
extern volatile uint32_t dbg_wrist_br_accumulator;

/* Wrist torque sensor */
extern volatile uint16_t dbg_wrist_torque_adc;
extern volatile float    dbg_wrist_torque_voltage;
extern volatile float    dbg_wrist_torque_centered_voltage;
extern volatile float    dbg_wrist_torque_value;

/* Wrist PID */
extern volatile float    dbg_wrist_setpoint_deg;
extern volatile float    dbg_wrist_feedback_deg;
extern volatile float    dbg_wrist_error_deg;

extern volatile float    dbg_wrist_pid_up;
extern volatile float    dbg_wrist_pid_ui;
extern volatile float    dbg_wrist_pid_ud;
extern volatile float    dbg_wrist_pid_ut;

extern volatile float    dbg_wrist_pid_output;
extern volatile float    dbg_wrist_pid_pwm_percent;
extern volatile uint8_t  dbg_wrist_pid_direction;
extern volatile uint8_t  dbg_wrist_pid_active;

/* Breakpoint helpers */
void breakpoint_after_inputs(void);
void breakpoint_before_send(void);
void breakpoint_after_send(void);
void breakpoint_after_wrist_encoder_read(void);
void breakpoint_after_wrist_torque_update(void);
void breakpoint_after_wrist_brushed_update(void);
void breakpoint_after_wrist_pid_update(void);

#endif