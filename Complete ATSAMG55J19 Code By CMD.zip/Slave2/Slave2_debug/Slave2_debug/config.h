#ifndef CONFIG_H
#define CONFIG_H

#include "sam.h"
#include <stdint.h>
#include <stdbool.h>

/* ============================================================
   CLOCK
   ============================================================ */

#define CPU_CLOCK_HZ                16000000u
#define SLOW_CLOCK_HZ               32768u

/* ============================================================
   SLAVE 2 I2C
   PA9  = SCL
   PA10 = SDA
   ============================================================ */

#define MY_I2C_ADDR                 0x21u

#define BUS_I2C_SCL                 PIO_PA9
#define BUS_I2C_SDA                 PIO_PA10

#ifndef ID_FLEXCOM0
#define ID_FLEXCOM0                 19u
#endif

#ifndef FLEX_MR_OPMODE_TWI
#define FLEX_MR_OPMODE_TWI          3u
#endif

#ifndef TWI_SR_RXRDY
#define TWI_SR_RXRDY                (1u << 1)
#endif

#ifndef TWI_SR_EOSACC
#define TWI_SR_EOSACC               (1u << 11)
#endif

#ifndef TWI_CR_SVEN
#define TWI_CR_SVEN                 (1u << 4)
#endif

#ifndef TWI_CR_MSDIS
#define TWI_CR_MSDIS                (1u << 3)
#endif

/* ============================================================
   COMMAND DEFINITIONS

   Master sends:

      cmd = profile * 3 + hand_cmd

   hand_cmd:
      0 = open
      1 = close
      2 = stop
   ============================================================ */

#define NUM_PROFILES                3u

#define HAND_OPEN                   0u
#define HAND_CLOSE                  1u
#define HAND_STOP                   2u

/* ============================================================
   SLAVE 2 MOTOR PINS

   PA0  = PWM
   PA30 = DIR
   PB14 = BRAKE
   PB15 = NSLEEP
   ============================================================ */

#define M1_PWM_PIN                  PIO_PA0
#define M1_DIR_PIN                  PIO_PA30
#define M1_BRK_PIN                  PIO_PB14
#define NSLEEP_PIN                  PIO_PB15

#define LED1_PIN                    PIO_PA14
#define LED2_PIN                    PIO_PA11

/*
   If open/close direction is backward, swap these.
*/
#define DIR_OPEN_LEVEL              0u
#define DIR_CLOSE_LEVEL             1u

#define BRAKE_RELEASE_LEVEL         0u
#define BRAKE_ACTIVE_LEVEL          1u

/* ============================================================
   PWM
   ============================================================ */

#define PWM_FREQ_HZ                 20000u

#define HAND_OPEN_PWM_PERCENT       100u
#define HAND_CLOSE_PWM_PERCENT      100u

#ifndef ID_TC0
#define ID_TC0                      23u
#endif

/* ============================================================
   CURRENT SENSE

   PA20 = current sense
   ADC channel 3
   ============================================================ */

#define HAND_CURRENT_ADC_PIN        PIO_PA20
#define HAND_CURRENT_ADC_CH         3u

/*
   Current limits for profile close stop / power-save.

   Profile 0 = light grip
   Profile 1 = medium grip
   Profile 2 = strong grip

   These are high test values first.
   Later tune lower after watching dbg_hand_current_adc.
*/
#define PROFILE0_CURRENT_LIMIT_ADC  100u
#define PROFILE1_CURRENT_LIMIT_ADC  150u
#define PROFILE2_CURRENT_LIMIT_ADC  200u

#define CURRENT_CONFIRM_COUNT_MAX   8u
#define CURRENT_IGNORE_START_MS     100u

#endif