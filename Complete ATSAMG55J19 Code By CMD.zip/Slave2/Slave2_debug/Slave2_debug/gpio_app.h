#ifndef GPIO_APP_H
#define GPIO_APP_H

#include "config.h"

void gpio_app_init(void);

void gpio_a_write(uint32_t pin, uint8_t level);
void gpio_b_write(uint32_t pin, uint8_t level);

#endif