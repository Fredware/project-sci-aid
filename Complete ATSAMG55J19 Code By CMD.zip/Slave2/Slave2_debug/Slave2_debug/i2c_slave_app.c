#include "sam.h"
#include "i2c_slave_app.h"
#include "config.h"
#include "debug_vars.h"

static volatile uint8_t rx_profile = 0u;
static volatile uint8_t rx_hand_cmd = HAND_STOP;

void i2c_slave_app_init(void)
{
    PMC->PMC_PCER0 |= (1u << ID_PIOA);
    PMC->PMC_PCER0 |= (1u << ID_FLEXCOM0);

    /*
       PA9 / PA10 to TWI0 peripheral.
       These are NOT GPIO while I2C is active.
    */
    PIOA->PIO_PDR = BUS_I2C_SCL | BUS_I2C_SDA;

    PIOA->PIO_ABCDSR[0] &= ~(BUS_I2C_SCL | BUS_I2C_SDA);
    PIOA->PIO_ABCDSR[1] &= ~(BUS_I2C_SCL | BUS_I2C_SDA);

    PIOA->PIO_PUER = BUS_I2C_SCL | BUS_I2C_SDA;

    FLEXCOM0->FLEXCOM_MR = FLEX_MR_OPMODE_TWI;

    TWI0->TWI_CR = TWI_CR_SWRST;
    TWI0->TWI_CR = TWI_CR_SVEN | TWI_CR_MSDIS;

    TWI0->TWI_SMR = ((uint32_t)MY_I2C_ADDR << 16);
}

void i2c_slave_app_poll(void)
{
    uint32_t sr;

    sr = TWI0->TWI_SR;
    dbg_last_twi0_sr = sr;

    if ((sr & TWI_SR_RXRDY) != 0u)
    {
        uint8_t b;
        uint8_t profile;
        uint8_t hand_cmd;

        b = (uint8_t)TWI0->TWI_RHR;

        dbg_last_rx_byte = b;

        /*
           Valid Slave 2 command:
           cmd = profile * 3 + hand_cmd
           0..8
        */
        if (b <= 8u)
        {
            profile = (uint8_t)(b / 3u);
            hand_cmd = (uint8_t)(b % 3u);

            rx_profile = profile;
            rx_hand_cmd = hand_cmd;

            dbg_last_profile = profile;
            dbg_last_hand_cmd = hand_cmd;
            dbg_valid_packet_count++;
            dbg_link_good = 1u;

            breakpoint_after_rx();
        }
        else
        {
            dbg_bad_packet_count++;
        }
    }

    if ((sr & TWI_SR_EOSACC) != 0u)
    {
        volatile uint32_t dummy;

        dummy = TWI0->TWI_SR;
        (void)dummy;
    }
}

uint8_t i2c_slave_get_profile(void)
{
    return rx_profile;
}

uint8_t i2c_slave_get_hand_cmd(void)
{
    return rx_hand_cmd;
}