#ifndef I2C_SLAVE_APP_H
#define I2C_SLAVE_APP_H

#include "config.h"

void i2c_slave_app_init(void);
void i2c_slave_app_poll(void);

uint8_t i2c_slave_get_profile(void);
uint8_t i2c_slave_get_hand_cmd(void);

#endif