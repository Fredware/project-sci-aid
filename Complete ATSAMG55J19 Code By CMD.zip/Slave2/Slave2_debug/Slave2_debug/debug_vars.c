#include "sam.h"
#include "debug_vars.h"

volatile uint32_t dbg_cpu_clock_hz = 0u;
volatile uint32_t dbg_clock_ok = 0u;
volatile uint32_t dbg_slow_clock_enabled = 0u;

volatile uint32_t dbg_PMC_MCKR = 0u;
volatile uint32_t dbg_CKGR_MOR = 0u;
volatile uint32_t dbg_PMC_SR = 0u;
volatile uint32_t dbg_SUPC_SR = 0u;

volatile uint32_t dbg_ms = 0u;

volatile uint32_t dbg_slave2_loop_count = 0u;

volatile uint32_t dbg_valid_packet_count = 0u;
volatile uint32_t dbg_bad_packet_count = 0u;

volatile uint8_t  dbg_last_rx_byte = 2u;
volatile uint8_t  dbg_last_profile = 0u;
volatile uint8_t  dbg_last_hand_cmd = 2u;
volatile uint8_t  dbg_link_good = 0u;

volatile uint32_t dbg_last_twi0_sr = 0u;

volatile uint8_t  dbg_motor_state = 0u;
volatile uint8_t  dbg_commanded_pwm = 0u;

volatile uint32_t dbg_pwm_rc = 0u;
volatile uint32_t dbg_pwm_duty = 0u;

volatile uint16_t dbg_hand_current_adc = 0u;
volatile float    dbg_hand_current_voltage = 0.0f;
volatile uint16_t dbg_current_limit_adc = 0u;
volatile uint8_t  dbg_power_save_hold = 0u;

void breakpoint_after_rx(void)
{
	__NOP();
}

void breakpoint_after_motor_update(void)
{
	__NOP();
}