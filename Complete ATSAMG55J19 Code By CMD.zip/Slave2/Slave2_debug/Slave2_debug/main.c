#include "sam.h"

#include "clock_app.h"
#include "delay_app.h"
#include "gpio_app.h"
#include "i2c_slave_app.h"
#include "motor_app.h"
#include "debug_vars.h"

/*
   SLAVE 2 MAIN

   main.c only calls app modules.
   Motor code is in motor_app.c.
   I2C code is in i2c_slave_app.c.
   GPIO code is in gpio_app.c.
*/

int main(void)
{
    SystemInit();
    WDT->WDT_MR = WDT_MR_WDDIS;

    clock_app_init();
    delay_app_init_1ms();

    gpio_app_init();
    motor_app_init();
    i2c_slave_app_init();

    while (1)
    {
        dbg_slave2_loop_count++;

        i2c_slave_app_poll();

        motor_app_update_from_command(
            i2c_slave_get_profile(),
            i2c_slave_get_hand_cmd()
        );
    }
}