#ifndef DEBUG_VARS_H
#define DEBUG_VARS_H

#include <stdint.h>

/* Clock debug */
extern volatile uint32_t dbg_cpu_clock_hz;
extern volatile uint32_t dbg_clock_ok;
extern volatile uint32_t dbg_slow_clock_enabled;

extern volatile uint32_t dbg_PMC_MCKR;
extern volatile uint32_t dbg_CKGR_MOR;
extern volatile uint32_t dbg_PMC_SR;
extern volatile uint32_t dbg_SUPC_SR;

extern volatile uint32_t dbg_ms;

/* Slave loop */
extern volatile uint32_t dbg_slave2_loop_count;

/* I2C receive */
extern volatile uint32_t dbg_valid_packet_count;
extern volatile uint32_t dbg_bad_packet_count;

extern volatile uint8_t  dbg_last_rx_byte;
extern volatile uint8_t  dbg_last_profile;
extern volatile uint8_t  dbg_last_hand_cmd;
extern volatile uint8_t  dbg_link_good;

extern volatile uint32_t dbg_last_twi0_sr;

/* Motor */
extern volatile uint8_t  dbg_motor_state;      /* 0 stop, 1 open, 2 close */
extern volatile uint8_t  dbg_commanded_pwm;

extern volatile uint32_t dbg_pwm_rc;
extern volatile uint32_t dbg_pwm_duty;

/* Current sense / power-save */
extern volatile uint16_t dbg_hand_current_adc;
extern volatile float    dbg_hand_current_voltage;
extern volatile uint16_t dbg_current_limit_adc;
extern volatile uint8_t  dbg_power_save_hold;

/* Breakpoints */
void breakpoint_after_rx(void);
void breakpoint_after_motor_update(void);

#endif