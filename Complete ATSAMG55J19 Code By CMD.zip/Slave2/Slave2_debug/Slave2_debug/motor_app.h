#ifndef MOTOR_APP_H
#define MOTOR_APP_H

#include "config.h"

void motor_app_init(void);

void motor_app_stop(void);
void motor_app_open(uint8_t pwm_percent);
void motor_app_close(uint8_t pwm_percent);

void motor_app_update_from_command(uint8_t profile, uint8_t hand_cmd);

#endif