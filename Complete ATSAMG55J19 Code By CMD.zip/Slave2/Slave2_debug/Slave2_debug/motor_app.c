#include "sam.h"

#include "motor_app.h"
#include "gpio_app.h"
#include "delay_app.h"
#include "debug_vars.h"
#include "config.h"

#ifndef TC_CMR_WAVSEL_UP_RC
#define TC_CMR_WAVSEL_UP_RC (2u << 13)
#endif

#ifndef TC_CMR_ACPA_CLEAR
#define TC_CMR_ACPA_CLEAR   (2u << 16)
#endif

#ifndef TC_CMR_ACPC_SET
#define TC_CMR_ACPC_SET     (1u << 18)
#endif

#ifndef TC_CMR_BCPB_CLEAR
#define TC_CMR_BCPB_CLEAR   (2u << 24)
#endif

#ifndef TC_CMR_BCPC_SET
#define TC_CMR_BCPC_SET     (1u << 26)
#endif

#ifndef TC_CMR_EEVT_XC0
#define TC_CMR_EEVT_XC0     (1u << 10)
#endif

/*
   Ignore current for this long after direction starts.
   This helps if current limit is low and motor has startup spike.
*/
//#ifndef CURRENT_IGNORE_START_MS
//#define CURRENT_IGNORE_START_MS     300u
//#endif

static uint32_t pwm_rc = 0u;
static uint32_t pwm_duty = 0u;

static uint8_t driver_is_awake = 0u;

/*
   Last motor state prevents PWM from restarting every loop.
   0 = stop
   1 = open
   2 = close
*/
static uint8_t last_motor_state = 0u;

/*
   Power-save holds.
   Once end current is reached, motor stays stopped until command changes.
*/
static uint8_t open_power_save_hold = 0u;
static uint8_t close_power_save_hold = 0u;

static uint8_t last_hand_cmd = HAND_STOP;
static uint8_t last_profile = 0u;

static uint16_t current_confirm_count = 0u;

/*
   Time when current checking becomes active.
*/
static uint32_t current_ignore_until_ms = 0u;

static uint16_t current_limits[NUM_PROFILES] =
{
    PROFILE0_CURRENT_LIMIT_ADC,
    PROFILE1_CURRENT_LIMIT_ADC,
    PROFILE2_CURRENT_LIMIT_ADC
};

/* ============================================================
   PWM PINS
   ============================================================ */

static void pwm_pins_gpio_low(void)
{
    PIOA->PIO_PER = M1_PWM_PIN;
    PIOA->PIO_OER = M1_PWM_PIN;
    PIOA->PIO_CODR = M1_PWM_PIN;
}

static void pwm_pins_tc(void)
{
    /*
       PA0 = TIOA0
    */
    PIOA->PIO_ABCDSR[0] |= M1_PWM_PIN;
    PIOA->PIO_ABCDSR[1] &= ~M1_PWM_PIN;

    PIOA->PIO_PDR = M1_PWM_PIN;
}

static void set_pwm_percent(uint8_t percent)
{
    if (percent > 100u)
    {
        percent = 100u;
    }

    pwm_duty = (pwm_rc * percent) / 100u;

    if (pwm_duty > pwm_rc)
    {
        pwm_duty = pwm_rc;
    }

    TC0->TC_CHANNEL[0].TC_RA = pwm_duty;
    TC0->TC_CHANNEL[0].TC_RB = pwm_duty;

    dbg_pwm_duty = pwm_duty;
}

static void pwm_on(void)
{
    pwm_pins_tc();

    TC0->TC_CHANNEL[0].TC_CCR = TC_CCR_CLKEN | TC_CCR_SWTRG;

    gpio_a_write(LED1_PIN, 1u);
}

static void pwm_off(void)
{
    TC0->TC_CHANNEL[0].TC_CCR = TC_CCR_CLKDIS;

    set_pwm_percent(0u);
    pwm_pins_gpio_low();

    gpio_a_write(LED1_PIN, 0u);
}

static void tc_pwm_init(void)
{
    PMC->PMC_PCER0 |= (1u << ID_TC0);

    /*
       CPU = 16 MHz.
       TC TIMER_CLOCK1 = CPU_CLOCK_HZ / 2.
       16 MHz / 2 / 20 kHz = 400.
    */
    pwm_rc = (CPU_CLOCK_HZ / 2u) / PWM_FREQ_HZ;

    dbg_pwm_rc = pwm_rc;

    TC0->TC_CHANNEL[0].TC_CCR = TC_CCR_CLKDIS;

    TC0->TC_CHANNEL[0].TC_CMR =
        TC_CMR_TCCLKS_TIMER_CLOCK1 |
        TC_CMR_WAVE |
        TC_CMR_WAVSEL_UP_RC |
        TC_CMR_EEVT_XC0 |
        TC_CMR_ACPA_CLEAR |
        TC_CMR_ACPC_SET |
        TC_CMR_BCPB_CLEAR |
        TC_CMR_BCPC_SET;

    TC0->TC_CHANNEL[0].TC_RC = pwm_rc;

    set_pwm_percent(0u);
    pwm_off();
}

/* ============================================================
   CURRENT ADC
   ============================================================ */

static void current_adc_init(void)
{
    PMC->PMC_PCER0 |= (1u << ID_ADC);

    /*
       PA20 = ADC channel 3.
    */
    PIOA->PIO_ODR = HAND_CURRENT_ADC_PIN;
    PIOA->PIO_PDR = HAND_CURRENT_ADC_PIN;

    ADC->ADC_CR = ADC_CR_SWRST;

    ADC->ADC_MR =
        ADC_MR_PRESCAL(15) |
        ADC_MR_STARTUP_SUT64 |
        ADC_MR_TRACKTIM(15);

    ADC->ADC_CHER = (1u << HAND_CURRENT_ADC_CH);
}

static uint16_t current_adc_read_one(void)
{
    ADC->ADC_CHER = (1u << HAND_CURRENT_ADC_CH);
    ADC->ADC_CR = ADC_CR_START;

    while ((ADC->ADC_ISR & (1u << HAND_CURRENT_ADC_CH)) == 0u)
    {
    }

    return (uint16_t)(ADC->ADC_CDR[HAND_CURRENT_ADC_CH] & 0x0FFFu);
}

static uint16_t current_adc_read_avg(void)
{
    uint32_t sum;
    uint16_t adc;

    sum = 0u;

    for (uint8_t i = 0u; i < 8u; i++)
    {
        sum += current_adc_read_one();
    }

    adc = (uint16_t)(sum / 8u);

    dbg_hand_current_adc = adc;
    dbg_hand_current_voltage = ((float)adc * 3.30f) / 4095.0f;

    return adc;
}

/* ============================================================
   DRIVER WAKE
   ============================================================ */

static void driver_wake_once(void)
{
    if (driver_is_awake == 0u)
    {
        gpio_b_write(NSLEEP_PIN, 1u);

        /*
           Wake delay only one time at startup.
           Not every loop.
        */
        delay_ms(250u);

        gpio_b_write(M1_BRK_PIN, BRAKE_RELEASE_LEVEL);

        driver_is_awake = 1u;
    }
}

/* ============================================================
   MOTOR CONTROL
   ============================================================ */

void motor_app_stop(void)
{
    if (last_motor_state != 0u)
    {
        pwm_off();
    }

    last_motor_state = 0u;

    dbg_motor_state = 0u;
    dbg_commanded_pwm = 0u;

    gpio_b_write(M1_BRK_PIN, BRAKE_RELEASE_LEVEL);
    gpio_a_write(LED2_PIN, 0u);
}

void motor_app_open(uint8_t pwm_percent)
{
    driver_wake_once();

    gpio_b_write(M1_BRK_PIN, BRAKE_RELEASE_LEVEL);

    /*
       Only change direction when first entering OPEN.
       Do not restart PWM every loop.
    */
    if (last_motor_state != 1u)
    {
        pwm_off();
        delay_ms(20u);

        gpio_a_write(M1_DIR_PIN, DIR_OPEN_LEVEL);
        delay_ms(20u);

        current_ignore_until_ms = dbg_ms + CURRENT_IGNORE_START_MS;
        current_confirm_count = 0u;

        set_pwm_percent(pwm_percent);
        pwm_on();

        last_motor_state = 1u;
    }
    else
    {
        set_pwm_percent(pwm_percent);
    }

    dbg_motor_state = 1u;
    dbg_commanded_pwm = pwm_percent;

    gpio_a_write(LED2_PIN, 1u);
}

void motor_app_close(uint8_t pwm_percent)
{
    driver_wake_once();

    gpio_b_write(M1_BRK_PIN, BRAKE_RELEASE_LEVEL);

    /*
       Only change direction when first entering CLOSE.
       Do not restart PWM every loop.
    */
    if (last_motor_state != 2u)
    {
        pwm_off();
        delay_ms(20u);

        gpio_a_write(M1_DIR_PIN, DIR_CLOSE_LEVEL);
        delay_ms(20u);

        current_ignore_until_ms = dbg_ms + CURRENT_IGNORE_START_MS;
        current_confirm_count = 0u;

        set_pwm_percent(pwm_percent);
        pwm_on();

        last_motor_state = 2u;
    }
    else
    {
        set_pwm_percent(pwm_percent);
    }

    dbg_motor_state = 2u;
    dbg_commanded_pwm = pwm_percent;

    gpio_a_write(LED2_PIN, 0u);
}

/* ============================================================
   CURRENT LIMIT CHECK
   ============================================================ */

static uint8_t current_check_allowed(void)
{
    /*
       Ignore startup current until timer expires.
    */
    if ((int32_t)(dbg_ms - current_ignore_until_ms) < 0)
    {
        return 0u;
    }

    return 1u;
}

static uint8_t current_limit_reached(uint16_t current_adc, uint16_t limit)
{
    if (!current_check_allowed())
    {
        current_confirm_count = 0u;
        return 0u;
    }

    if (current_adc >= limit)
    {
        current_confirm_count++;

        if (current_confirm_count >= CURRENT_CONFIRM_COUNT_MAX)
        {
            current_confirm_count = 0u;
            return 1u;
        }
    }
    else
    {
        current_confirm_count = 0u;
    }

    return 0u;
}

/* ============================================================
   COMMAND UPDATE
   ============================================================ */

void motor_app_update_from_command(uint8_t profile, uint8_t hand_cmd)
{
    uint16_t current_adc;
    uint16_t limit;

    if (profile >= NUM_PROFILES)
    {
        profile = 0u;
    }

    /*
       If profile or command changes, clear power-save holds.
       This allows the next movement.
    */
    if ((profile != last_profile) || (hand_cmd != last_hand_cmd))
    {
        open_power_save_hold = 0u;
        close_power_save_hold = 0u;
        current_confirm_count = 0u;

        last_profile = profile;
        last_hand_cmd = hand_cmd;
    }

    limit = current_limits[profile];

    dbg_current_limit_adc = limit;
    dbg_power_save_hold = open_power_save_hold | close_power_save_hold;

    current_adc = current_adc_read_avg();

    /*
       STOP command.
    */
    if (hand_cmd == HAND_STOP)
    {
        current_confirm_count = 0u;
        open_power_save_hold = 0u;
        close_power_save_hold = 0u;

        motor_app_stop();

        breakpoint_after_motor_update();
        return;
    }

    /*
       OPEN command.
       Open stops when current reaches profile limit.
    */
    if (hand_cmd == HAND_OPEN)
    {
        close_power_save_hold = 0u;

        if (open_power_save_hold)
        {
            motor_app_stop();

            breakpoint_after_motor_update();
            return;
        }

        motor_app_open(HAND_OPEN_PWM_PERCENT);

        if (current_limit_reached(current_adc, limit))
        {
            open_power_save_hold = 1u;

            motor_app_stop();

            breakpoint_after_motor_update();
            return;
        }

        breakpoint_after_motor_update();
        return;
    }

    /*
       CLOSE command.
       Close stops when current reaches profile limit.
    */
    if (hand_cmd == HAND_CLOSE)
    {
        open_power_save_hold = 0u;

        if (close_power_save_hold)
        {
            motor_app_stop();

            breakpoint_after_motor_update();
            return;
        }

        motor_app_close(HAND_CLOSE_PWM_PERCENT);

        if (current_limit_reached(current_adc, limit))
        {
            close_power_save_hold = 1u;

            motor_app_stop();

            breakpoint_after_motor_update();
            return;
        }

        breakpoint_after_motor_update();
        return;
    }

    /*
       Invalid command = stop.
    */
    current_confirm_count = 0u;
    open_power_save_hold = 0u;
    close_power_save_hold = 0u;

    motor_app_stop();

    breakpoint_after_motor_update();
}

/* ============================================================
   INIT
   ============================================================ */

void motor_app_init(void)
{
    driver_is_awake = 0u;
    last_motor_state = 0u;

    open_power_save_hold = 0u;
    close_power_save_hold = 0u;

    last_hand_cmd = HAND_STOP;
    last_profile = 0u;

    current_confirm_count = 0u;
    current_ignore_until_ms = 0u;

    gpio_b_write(NSLEEP_PIN, 0u);
    gpio_b_write(M1_BRK_PIN, BRAKE_RELEASE_LEVEL);

    current_adc_init();
    tc_pwm_init();

    driver_wake_once();

    motor_app_stop();
}