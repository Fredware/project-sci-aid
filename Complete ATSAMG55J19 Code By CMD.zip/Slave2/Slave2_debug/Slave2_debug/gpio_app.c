#include "sam.h"
#include "gpio_app.h"
#include "config.h"

static void pioa_output_enable(uint32_t pin)
{
	PIOA->PIO_PER = pin;
	PIOA->PIO_OER = pin;
}

static void piob_output_enable(uint32_t pin)
{
	PIOB->PIO_PER = pin;
	PIOB->PIO_OER = pin;
}

void gpio_a_write(uint32_t pin, uint8_t level)
{
	if (level)
	{
		PIOA->PIO_SODR = pin;
	}
	else
	{
		PIOA->PIO_CODR = pin;
	}
}

void gpio_b_write(uint32_t pin, uint8_t level)
{
	if (level)
	{
		PIOB->PIO_SODR = pin;
	}
	else
	{
		PIOB->PIO_CODR = pin;
	}
}

void gpio_app_init(void)
{
	PMC->PMC_PCER0 |= (1u << ID_PIOA);
	PMC->PMC_PCER0 |= (1u << ID_PIOB);

	pioa_output_enable(M1_PWM_PIN);
	pioa_output_enable(M1_DIR_PIN);
	pioa_output_enable(LED1_PIN);
	pioa_output_enable(LED2_PIN);

	piob_output_enable(M1_BRK_PIN);
	piob_output_enable(NSLEEP_PIN);

	gpio_a_write(M1_PWM_PIN, 0u);
	gpio_a_write(M1_DIR_PIN, 0u);
	gpio_a_write(LED1_PIN, 0u);
	gpio_a_write(LED2_PIN, 0u);

	gpio_b_write(M1_BRK_PIN, BRAKE_RELEASE_LEVEL);
	gpio_b_write(NSLEEP_PIN, 0u);
}