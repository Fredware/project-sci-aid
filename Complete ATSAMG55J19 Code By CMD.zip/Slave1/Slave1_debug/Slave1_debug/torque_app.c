#include "sam.h"
#include <stdint.h>

#include "config.h"
#include "torque_app.h"
#include "debug_vars.h"

/*
   TORQUE SENSOR APP

   HAL_SENSE op-amp output goes to ADC.

   Simple calculation:

      voltage = adc * 3.3 / 4095

      centered_voltage = voltage - TORQUE_MID_VOLTAGE

      if centered_voltage is inside deadband:
          torque_value = 0

      else:
          torque_value = centered_voltage * TORQUE_SCALE

   No software filter.
   No slew limit.
   No output limit.
*/

static uint16_t torque_adc = 0u;
static float torque_voltage = 0.0f;
static float torque_centered_voltage = 0.0f;
static float torque_value = 0.0f;

static uint16_t torque_adc_read_one(void)
{
    ADC->ADC_CHER = (1u << TORQUE_SENSOR_ADC_CH);
    ADC->ADC_CR = ADC_CR_START;

    while ((ADC->ADC_ISR & (1u << TORQUE_SENSOR_ADC_CH)) == 0u)
    {
        /* wait */
    }

    return (uint16_t)(ADC->ADC_CDR[TORQUE_SENSOR_ADC_CH] & 0x0FFFu);
}

static uint16_t torque_adc_read_avg(void)
{
    uint32_t sum;

    sum = 0u;

    for (uint8_t i = 0u; i < 16u; i++)
    {
        sum += torque_adc_read_one();
    }

    return (uint16_t)(sum / 16u);
}

void torque_app_init(void)
{
    PMC->PMC_PCER0 |= (1u << ID_ADC);
    PMC->PMC_PCER0 |= (1u << ID_PIOA);

    /*
       Torque input pin.
       Example: PA19 / ADC channel 2.
    */
    PIOA->PIO_ODR = TORQUE_SENSOR_ADC_PIN;
    PIOA->PIO_PDR = TORQUE_SENSOR_ADC_PIN;

    ADC->ADC_CR = ADC_CR_SWRST;

    ADC->ADC_MR =
        ADC_MR_PRESCAL(15) |
        ADC_MR_STARTUP_SUT64 |
        ADC_MR_TRACKTIM(15);

    ADC->ADC_CHER = (1u << TORQUE_SENSOR_ADC_CH);

    torque_adc = 0u;
    torque_voltage = 0.0f;
    torque_centered_voltage = 0.0f;
    torque_value = 0.0f;

    dbg_torque_adc = 0u;
    dbg_torque_voltage = 0.0f;
    dbg_torque_centered_voltage = 0.0f;
    dbg_torque_value = 0.0f;
}

void torque_app_update(void)
{
    float centered;

    torque_adc = torque_adc_read_avg();

    torque_voltage =
        ((float)torque_adc * TORQUE_ADC_REF_VOLTAGE) / TORQUE_ADC_MAX_COUNT;

    centered = torque_voltage - TORQUE_MID_VOLTAGE;

    if ((centered < TORQUE_DEADBAND_VOLT) &&
        (centered > -TORQUE_DEADBAND_VOLT))
    {
        centered = 0.0f;
    }

    torque_centered_voltage = centered;
    torque_value = torque_centered_voltage * TORQUE_SCALE;

    dbg_torque_adc = torque_adc;
    dbg_torque_voltage = torque_voltage;
    dbg_torque_centered_voltage = torque_centered_voltage;
    dbg_torque_value = torque_value;

    breakpoint_after_torque_update();
}

uint16_t torque_app_get_adc(void)
{
    return torque_adc;
}

float torque_app_get_voltage(void)
{
    return torque_voltage;
}

float torque_app_get_centered_voltage(void)
{
    return torque_centered_voltage;
}

float torque_app_get_value(void)
{
    return torque_value;
}