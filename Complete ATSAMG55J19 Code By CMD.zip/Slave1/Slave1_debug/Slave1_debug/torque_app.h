#ifndef TORQUE_APP_H
#define TORQUE_APP_H

#include <stdint.h>

void torque_app_init(void);
void torque_app_update(void);

uint16_t torque_app_get_adc(void);
float torque_app_get_voltage(void);
float torque_app_get_centered_voltage(void);
float torque_app_get_value(void);

#endif