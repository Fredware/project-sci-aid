#ifndef MOTOR_APP_H
#define MOTOR_APP_H

#include "config.h"

void motor_app_init(void);

void motor_app_stop(void);
void motor_app_forward(uint8_t pwm_percent);
void motor_app_reverse(uint8_t pwm_percent);

/* Runs forward/stop/reverse/stop test */
void motor_app_test_update(void);

#endif