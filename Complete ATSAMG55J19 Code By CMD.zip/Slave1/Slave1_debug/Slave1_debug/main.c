#include "sam.h"

#include "config.h"
#include "clock_app.h"
#include "delay_app.h"
#include "i2c_slave_app.h"
#include "encoder_app.h"
#include "motor_app.h"
#include "pid_app.h"
#include "torque_app.h"
#include "debug_vars.h"

/*
   SLAVE 1 FLEXION / EXTENSION PID

   Working:
   - I2C receive from Master
   - Encoder read
   - Calibrated flex/ext angle
   - Motor PWM
   - PID position control

   New:
   - Torque sensor read through torque_app
   - PID can use KT * torque_value
*/

int main(void)
{
    SystemInit();
    WDT->WDT_MR = WDT_MR_WDDIS;

    clock_app_init();
    delay_app_init_1ms();

    i2c_slave_app_init();
    encoder_app_init();
    motor_app_init();
    torque_app_init();
    pid_app_init();

    while (1)
    {
        dbg_slave1_loop_count++;

        i2c_slave_app_poll();

        encoder_app_update();

        torque_app_update();

        pid_app_update();

        delay_ms(10u);
    }
}