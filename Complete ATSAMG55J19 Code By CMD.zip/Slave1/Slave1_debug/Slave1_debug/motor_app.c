#include "sam.h"
#include "motor_app.h"
#include "config.h"
#include "debug_vars.h"
#include "delay_app.h"

/*
   SLAVE 1 MOTOR PWM TEST - FIXED PA0 PWM PERIPHERAL

   PA0  = PWM using TC0 channel 0 TIOA0
   PA30 = DIR
   PB14 = BRAKE
   PB15 = nSLEEP

   This uses the same proven PA0 peripheral setup style
   as your working motor hardware test.

   Test sequence:
   Forward 2 sec
   Stop    1 sec
   Reverse 2 sec
   Stop    1 sec
   Repeat
*/

#ifndef TC_CMR_WAVSEL_UP_RC
#define TC_CMR_WAVSEL_UP_RC (2u << 13)
#endif

#ifndef TC_CMR_ACPA_CLEAR
#define TC_CMR_ACPA_CLEAR   (2u << 16)
#endif

#ifndef TC_CMR_ACPC_SET
#define TC_CMR_ACPC_SET     (1u << 18)
#endif

#ifndef TC_CMR_EEVT_XC0
#define TC_CMR_EEVT_XC0     (1u << 10)
#endif

static uint32_t pwm_rc = 0u;
static uint32_t pwm_duty = 0u;

static void motor_set_dir(uint8_t dir_level)
{
    if (dir_level)
    {
        PIOA->PIO_SODR = M1_DIR_PIN;
    }
    else
    {
        PIOA->PIO_CODR = M1_DIR_PIN;
    }

    dbg_motor_dir_level = dir_level;
}

static void motor_set_brake(uint8_t brake_level)
{
    if (brake_level)
    {
        PIOB->PIO_SODR = M1_BRK_PIN;
    }
    else
    {
        PIOB->PIO_CODR = M1_BRK_PIN;
    }
}

static void motor_set_sleep(uint8_t sleep_level)
{
    if (sleep_level)
    {
        PIOB->PIO_SODR = NSLEEP_PIN;
    }
    else
    {
        PIOB->PIO_CODR = NSLEEP_PIN;
    }
}

static void pwm_pin_tc(void)
{
    /*
       IMPORTANT FIX:

       Working motor test used this style for PA0 PWM:

       ABCDSR[0] |= PA0
       ABCDSR[1] &= PA0
       PDR = PA0

       That selects the correct peripheral for TC0 TIOA0.
    */

    PIOA->PIO_ABCDSR[0] |= M1_PWM_PIN;
    PIOA->PIO_ABCDSR[1] &= ~M1_PWM_PIN;

    PIOA->PIO_PDR = M1_PWM_PIN;
}

static void pwm_pin_gpio_low(void)
{
    /*
       Give PA0 back to GPIO and drive low.
       Same idea as old working pwm_off().
    */

    PIOA->PIO_PER = M1_PWM_PIN;
    PIOA->PIO_OER = M1_PWM_PIN;
    PIOA->PIO_CODR = M1_PWM_PIN;
}

static void pwm_set_percent(uint8_t percent)
{
    if (percent > 100u)
    {
        percent = 100u;
    }

    pwm_duty = (pwm_rc * (uint32_t)percent) / 100u;

    if (pwm_duty > pwm_rc)
    {
        pwm_duty = pwm_rc;
    }

    TC0->TC_CHANNEL[0].TC_RA = pwm_duty;

    dbg_commanded_pwm_percent = percent;
    dbg_tc0_rc = pwm_rc;
    dbg_tc0_ra = pwm_duty;
}

static void pwm_on(void)
{
    pwm_pin_tc();

    TC0->TC_CHANNEL[0].TC_CCR = TC_CCR_CLKEN | TC_CCR_SWTRG;
}

static void pwm_off_local(void)
{
    TC0->TC_CHANNEL[0].TC_CCR = TC_CCR_CLKDIS;

    pwm_pin_gpio_low();

    dbg_commanded_pwm_percent = 0u;
    dbg_tc0_ra = 0u;
}

void motor_app_stop(void)
{
    pwm_set_percent(0u);
    pwm_off_local();

    /*
       Brake active during stop.
       If this makes restart hard, we can later change stop to brake release.
    */
    motor_set_brake(BRAKE_ACTIVE_LEVEL);

    dbg_motor_state = 0u;
}

void motor_app_forward(uint8_t pwm_percent)
{
    motor_set_sleep(NSLEEP_WAKE_LEVEL);
    motor_set_brake(BRAKE_RELEASE_LEVEL);

    /*
       Based on your old working code:
       CW = DIR LOW.
       So forward here uses LOW first.
    */
    motor_set_dir(0u);

    pwm_set_percent(pwm_percent);
    pwm_on();

    dbg_motor_state = 1u;
}

void motor_app_reverse(uint8_t pwm_percent)
{
    motor_set_sleep(NSLEEP_WAKE_LEVEL);
    motor_set_brake(BRAKE_RELEASE_LEVEL);

    /*
       Reverse = DIR HIGH.
    */
    motor_set_dir(1u);

    pwm_set_percent(pwm_percent);
    pwm_on();

    dbg_motor_state = 2u;
}

void motor_app_init(void)
{
    PMC->PMC_PCER0 |= (1u << ID_PIOA);
    PMC->PMC_PCER0 |= (1u << ID_PIOB);
    PMC->PMC_PCER0 |= (1u << ID_TC0);

    /*
       DIR and LEDs as GPIO outputs.
    */
    PIOA->PIO_PER = M1_DIR_PIN | LED1_PIN | LED2_PIN;
    PIOA->PIO_OER = M1_DIR_PIN | LED1_PIN | LED2_PIN;

    /*
       Brake and nSLEEP as GPIO outputs.
    */
    PIOB->PIO_PER = M1_BRK_PIN | NSLEEP_PIN;
    PIOB->PIO_OER = M1_BRK_PIN | NSLEEP_PIN;

    PIOA->PIO_CODR = LED1_PIN | LED2_PIN;

    /*
       Safe driver state first.
    */
    motor_set_sleep(NSLEEP_WAKE_LEVEL);
    motor_set_brake(BRAKE_RELEASE_LEVEL);
    motor_set_dir(0u);
    pwm_pin_gpio_low();

    /*
       TC0 channel 0 waveform mode.
       TIMER_CLOCK1 = MCK / 2 = 8 MHz.
       PWM 20 kHz:
       RC = 8 MHz / 20 kHz = 400.
    */
    pwm_rc = (CPU_CLOCK_HZ / 2u) / PWM_FREQ_HZ;

    if (pwm_rc < 10u)
    {
        pwm_rc = 10u;
    }

    TC0->TC_CHANNEL[0].TC_CCR = TC_CCR_CLKDIS;
    TC0->TC_CHANNEL[0].TC_IDR = 0xFFFFFFFFu;

    TC0->TC_CHANNEL[0].TC_CMR =
        TC_CMR_TCCLKS_TIMER_CLOCK1 |
        TC_CMR_WAVE |
        TC_CMR_WAVSEL_UP_RC |
        TC_CMR_EEVT_XC0 |
        TC_CMR_ACPA_CLEAR |
        TC_CMR_ACPC_SET;

    TC0->TC_CHANNEL[0].TC_RC = pwm_rc;
    TC0->TC_CHANNEL[0].TC_RA = 0u;

    dbg_tc0_rc = pwm_rc;
    dbg_tc0_ra = 0u;

    dbg_motor_test_step = 0u;
    dbg_motor_test_step_start_ms = dbg_ms;

    /*
       Wake/clear style.
    */
    motor_set_sleep(NSLEEP_SLEEP_LEVEL);
    delay_ms(20u);

    motor_set_sleep(NSLEEP_WAKE_LEVEL);
    delay_ms(250u);

    motor_set_brake(BRAKE_RELEASE_LEVEL);

    motor_app_stop();
}

void motor_app_test_update(void)
{
    uint32_t elapsed;

    elapsed = dbg_ms - dbg_motor_test_step_start_ms;

    switch (dbg_motor_test_step)
    {
        case 0u:
        {
            motor_app_forward(MOTOR_TEST_PWM_PERCENT);

            if (elapsed >= MOTOR_TEST_RUN_MS)
            {
                dbg_motor_test_step = 1u;
                dbg_motor_test_step_start_ms = dbg_ms;
            }

            break;
        }

        case 1u:
        {
            motor_app_stop();

            if (elapsed >= MOTOR_TEST_STOP_MS)
            {
                dbg_motor_test_step = 2u;
                dbg_motor_test_step_start_ms = dbg_ms;
            }

            break;
        }

        case 2u:
        {
            motor_app_reverse(MOTOR_TEST_PWM_PERCENT);

            if (elapsed >= MOTOR_TEST_RUN_MS)
            {
                dbg_motor_test_step = 3u;
                dbg_motor_test_step_start_ms = dbg_ms;
            }

            break;
        }

        case 3u:
        default:
        {
            motor_app_stop();

            if (elapsed >= MOTOR_TEST_STOP_MS)
            {
                dbg_motor_test_step = 0u;
                dbg_motor_test_step_start_ms = dbg_ms;
            }

            break;
        }
    }

    breakpoint_after_motor_update();
}