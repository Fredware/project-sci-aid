#include "sam.h"
#include "debug_vars.h"

/* ============================================================
   CLOCK DEBUG
   ============================================================ */

volatile uint32_t dbg_cpu_clock_hz = 0u;
volatile uint32_t dbg_clock_ok = 0u;
volatile uint32_t dbg_slow_clock_enabled = 0u;

volatile uint32_t dbg_PMC_MCKR = 0u;
volatile uint32_t dbg_CKGR_MOR = 0u;
volatile uint32_t dbg_PMC_SR = 0u;
volatile uint32_t dbg_SUPC_SR = 0u;

volatile uint32_t dbg_ms = 0u;

/* ============================================================
   SLAVE 1 LOOP
   ============================================================ */

volatile uint32_t dbg_slave1_loop_count = 0u;

/* ============================================================
   I2C RECEIVE FROM MASTER
   ============================================================ */

volatile uint32_t dbg_valid_packet_count = 0u;
volatile uint32_t dbg_bad_packet_count = 0u;

volatile uint8_t  dbg_last_rx_byte = 0u;
volatile uint8_t  dbg_last_profile = 0u;
volatile uint8_t  dbg_last_position = 0u;
volatile uint8_t  dbg_link_good = 0u;

volatile uint32_t dbg_last_twi0_sr = 0u;

/* ============================================================
   ENCODER DEBUG
   ============================================================ */

volatile uint16_t dbg_encoder_raw = 0u;
volatile float    dbg_encoder_deg = 0.0f;
volatile float    dbg_flex_ext_deg = 0.0f;

volatile uint32_t dbg_encoder_read_count = 0u;
volatile uint8_t  dbg_encoder_ok = 0u;
volatile uint32_t dbg_last_twi5_sr = 0u;

/* ============================================================
   MOTOR DEBUG
   ============================================================ */

volatile uint8_t  dbg_motor_state = 0u;
volatile uint8_t  dbg_motor_dir_level = 0u;
volatile uint8_t  dbg_commanded_pwm_percent = 0u;
volatile uint32_t dbg_motor_test_step = 0u;
volatile uint32_t dbg_motor_test_step_start_ms = 0u;
volatile uint32_t dbg_tc0_rc = 0u;
volatile uint32_t dbg_tc0_ra = 0u;

/* ============================================================
   PID DEBUG
   ============================================================ */

volatile float    dbg_pid_setpoint_deg = 0.0f;
volatile float    dbg_pid_feedback_deg = 0.0f;
volatile float    dbg_pid_error_deg = 0.0f;

volatile float    dbg_pid_up = 0.0f;
volatile float    dbg_pid_ui = 0.0f;
volatile float    dbg_pid_ud = 0.0f;
volatile float    dbg_pid_ut = 0.0f;
volatile float    dbg_pid_um = 0.0f;

volatile float    dbg_pid_output = 0.0f;
volatile float    dbg_pid_pwm_percent = 0.0f;
volatile uint8_t  dbg_pid_direction = 0u;
volatile uint8_t  dbg_pid_active = 0u;

/* ============================================================
   TORQUE SENSOR DEBUG
   ============================================================ */

volatile uint16_t dbg_torque_adc = 0u;
volatile float    dbg_torque_voltage = 0.0f;
volatile float    dbg_torque_centered_voltage = 0.0f;
volatile float    dbg_torque_value = 0.0f;

/* ============================================================
   BREAKPOINT HELPERS
   ============================================================ */

void breakpoint_after_rx(void)
{
    __NOP();
}

void breakpoint_after_encoder_read(void)
{
    __NOP();
}

void breakpoint_after_motor_update(void)
{
    __NOP();
}

void breakpoint_after_pid_update(void)
{
    __NOP();
}

void breakpoint_after_torque_update(void)
{
    __NOP();
}