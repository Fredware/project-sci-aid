#include "sam.h"
#include "encoder_app.h"
#include "config.h"
#include "debug_vars.h"

/*
   SLAVE 1 FLEXION / EXTENSION ENCODER DEBUG

   PA12 = SCL
   PA13 = SDA
   TWI5 / FLEXCOM5

   Encoder address = 0x36
   Angle register  = 0x0E

   This keeps two angle values:

   1) dbg_encoder_deg
      Normal raw 0 to 360 degree angle.

   2) dbg_flex_ext_deg
      Calibrated flexion / extension angle.

      Down   raw = 553   -> -100 deg
      Middle raw = 1837  -> 0 deg
      Up     raw = 2707  -> +100 deg
*/

static uint16_t encoder_raw = 0u;
static float encoder_deg = 0.0f;
static float flex_ext_deg = 0.0f;

static float wrap360(float angle)
{
    while (angle >= 360.0f)
    {
        angle -= 360.0f;
    }

    while (angle < 0.0f)
    {
        angle += 360.0f;
    }

    return angle;
}

static float clamp_float(float x, float min_val, float max_val)
{
    if (x > max_val)
    {
        return max_val;
    }

    if (x < min_val)
    {
        return min_val;
    }

    return x;
}

static float map_float(float x,
                       float in_min,
                       float in_max,
                       float out_min,
                       float out_max)
{
    return ((x - in_min) * (out_max - out_min) / (in_max - in_min)) + out_min;
}

static float raw_to_degree(uint16_t raw)
{
    raw &= 0x0FFFu;

    return wrap360(((float)raw * 360.0f) / ENCODER_COUNTS);
}

static float raw_to_flex_ext_degree(uint16_t raw)
{
    float raw_f;
    float deg;

    raw_f = (float)(raw & 0x0FFFu);

    /*
       Piecewise calibration:

       Down to Middle:
       raw 553 -> -100 deg
       raw 1837 -> 0 deg

       Middle to Up:
       raw 1837 -> 0 deg
       raw 2707 -> +100 deg
    */

    if (raw_f <= FLEX_MID_RAW)
    {
        deg = map_float(raw_f,
                        FLEX_DOWN_RAW,
                        FLEX_MID_RAW,
                        FLEX_DOWN_DEG,
                        FLEX_MID_DEG);
    }
    else
    {
        deg = map_float(raw_f,
                        FLEX_MID_RAW,
                        FLEX_UP_RAW,
                        FLEX_MID_DEG,
                        FLEX_UP_DEG);
    }

    /*
       Clamp for safety/debug.
       Allows a little extra beyond +/-100.
    */
    deg = clamp_float(deg, -120.0f, 120.0f);

    return deg;
}

void encoder_app_init(void)
{
    uint32_t cldiv;

    PMC->PMC_PCER0 |= (1u << ID_PIOA);
    PMC->PMC_PCER0 |= (1u << ID_FLEXCOM5);

    /*
       PA12 / PA13 to TWI5 peripheral.
       These are NOT GPIO when encoder I2C is active.
    */
    PIOA->PIO_PDR = ENCODER_I2C_SCL | ENCODER_I2C_SDA;

    PIOA->PIO_ABCDSR[0] &= ~(ENCODER_I2C_SCL | ENCODER_I2C_SDA);
    PIOA->PIO_ABCDSR[1] &= ~(ENCODER_I2C_SCL | ENCODER_I2C_SDA);

    PIOA->PIO_PUER = ENCODER_I2C_SCL | ENCODER_I2C_SDA;

    FLEXCOM5->FLEXCOM_MR = FLEX_MR_OPMODE_TWI;

    TWI5->TWI_CR = TWI_CR_SWRST;
    TWI5->TWI_CR = TWI_CR_MSEN | TWI_CR_SVDIS;

    /*
       100 kHz encoder I2C.
       CPU clock = 16 MHz.
    */
    cldiv = ((CPU_CLOCK_HZ / 100000u) - 4u) / 2u;

    TWI5->TWI_CWGR = (cldiv << 0) | (cldiv << 8);

    dbg_encoder_ok = 0u;
}

static uint8_t twi5_wait(uint32_t mask)
{
    uint32_t timeout;

    timeout = 100000u;

    while (1)
    {
        uint32_t sr;

        sr = TWI5->TWI_SR;
        dbg_last_twi5_sr = sr;

        if ((sr & TWI_SR_NACK) != 0u)
        {
            TWI5->TWI_CR = TWI_CR_STOP;
            return 0u;
        }

        if ((sr & mask) != 0u)
        {
            return 1u;
        }

        if (--timeout == 0u)
        {
            return 0u;
        }
    }
}

static uint8_t encoder_write_register(uint8_t reg)
{
    TWI5->TWI_MMR = ((uint32_t)ENCODER_ADDRESS << 16);

    if (!twi5_wait(TWI_SR_TXRDY))
    {
        return 0u;
    }

    TWI5->TWI_THR = reg;

    if (!twi5_wait(TWI_SR_TXRDY))
    {
        return 0u;
    }

    TWI5->TWI_CR = TWI_CR_STOP;

    if (!twi5_wait(TWI_SR_TXCOMP))
    {
        return 0u;
    }

    return 1u;
}

static uint8_t encoder_read_raw(uint16_t *raw_out)
{
    uint8_t angle_hi;
    uint8_t angle_lo;
    uint16_t raw;

    if (!encoder_write_register(ANGLE_REGISTER_ADDRESS))
    {
        return 0u;
    }

    TWI5->TWI_MMR = ((uint32_t)ENCODER_ADDRESS << 16) | TWI_MMR_MREAD;

    TWI5->TWI_CR = TWI_CR_START;

    if (!twi5_wait(TWI_SR_RXRDY))
    {
        return 0u;
    }

    angle_hi = (uint8_t)TWI5->TWI_RHR;

    TWI5->TWI_CR = TWI_CR_STOP;

    if (!twi5_wait(TWI_SR_RXRDY))
    {
        return 0u;
    }

    angle_lo = (uint8_t)TWI5->TWI_RHR;

    if (!twi5_wait(TWI_SR_TXCOMP))
    {
        return 0u;
    }

    /*
       Same byte swap idea as Arduino code.
       Normal high byte should not have upper 4 bits set.
    */
    if ((angle_hi & 0xF0u) != 0u)
    {
        uint8_t temp;

        temp = angle_hi;
        angle_hi = angle_lo;
        angle_lo = temp;
    }

    raw = ((((uint16_t)angle_hi << 8) | angle_lo) & 0x0FFFu);

    *raw_out = raw;

    return 1u;
}

void encoder_app_update(void)
{
    uint16_t raw;

    if (encoder_read_raw(&raw))
    {
        encoder_raw = raw;

        encoder_deg = raw_to_degree(raw);
        flex_ext_deg = raw_to_flex_ext_degree(raw);

        dbg_encoder_raw = encoder_raw;
        dbg_encoder_deg = encoder_deg;
        dbg_flex_ext_deg = flex_ext_deg;

        dbg_encoder_read_count++;
        dbg_encoder_ok = 1u;
    }
    else
    {
        dbg_encoder_ok = 0u;
    }

    breakpoint_after_encoder_read();
}

uint16_t encoder_app_get_raw(void)
{
    return encoder_raw;
}

float encoder_app_get_deg(void)
{
    return flex_ext_deg;
}