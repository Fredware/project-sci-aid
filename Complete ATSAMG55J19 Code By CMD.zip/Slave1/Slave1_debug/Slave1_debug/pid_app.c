#include "sam.h"
#include "pid_app.h"
#include "config.h"
#include "debug_vars.h"
#include "encoder_app.h"
#include "motor_app.h"
#include "torque_app.h"

/*
   SLAVE 1 FLEXION / EXTENSION PID + TORQUE TERM

   Position part:
      u_p = KP * error
      u_i = KI * accumulated error
      u_d = KD * error difference

   Torque part:
      u_t = KT * torque_value

   Acceleration part:
      u_m = KM * acceleration

   Total:
      output = u_p + u_i + u_d + u_t + u_m

   For now:
      KI = 0
      KD = 0
      KM = 0
      KT active but start low
*/

static float integral = 0.0f;
static float error_prev = 0.0f;

static float feedback_prev = 0.0f;
static float velocity_prev = 0.0f;

static float clamp_float(float x, float min_val, float max_val)
{
    if (x > max_val)
    {
        return max_val;
    }

    if (x < min_val)
    {
        return min_val;
    }

    return x;
}

static float abs_float(float x)
{
    if (x < 0.0f)
    {
        return -x;
    }

    return x;
}

static float get_setpoint_from_command(void)
{
    uint8_t profile;
    uint8_t position;

    profile = dbg_last_profile;
    position = dbg_last_position;

    if (profile == 0u)
    {
        if (position == POS_A)
        {
            return PROFILE0_POS0_DEG;
        }
        else
        {
            return PROFILE0_POS1_DEG;
        }
    }
    else if (profile == 1u)
    {
        if (position == POS_A)
        {
            return PROFILE1_POS0_DEG;
        }
        else
        {
            return PROFILE1_POS1_DEG;
        }
    }
    else
    {
        if (position == POS_A)
        {
            return PROFILE2_POS0_DEG;
        }
        else
        {
            return PROFILE2_POS1_DEG;
        }
    }
}

void pid_app_init(void)
{
    integral = 0.0f;
    error_prev = 0.0f;
    feedback_prev = 0.0f;
    velocity_prev = 0.0f;

    dbg_pid_setpoint_deg = 0.0f;
    dbg_pid_feedback_deg = 0.0f;
    dbg_pid_error_deg = 0.0f;

    dbg_pid_up = 0.0f;
    dbg_pid_ui = 0.0f;
    dbg_pid_ud = 0.0f;
    dbg_pid_ut = 0.0f;
    dbg_pid_um = 0.0f;

    dbg_pid_output = 0.0f;
    dbg_pid_pwm_percent = 0.0f;
    dbg_pid_direction = 0u;
    dbg_pid_active = 0u;

    motor_app_stop();
}

float pid_app_get_setpoint(void)
{
    return get_setpoint_from_command();
}

void pid_app_update(void)
{
    float setpoint;
    float feedback;
    float error;

    float velocity;
    float acceleration;

    float torque_value;

    float u_p;
    float u_i;
    float u_d;
    float u_t;
    float u_m;

    float output;
    float pwm_percent;

    setpoint = get_setpoint_from_command();
    feedback = encoder_app_get_deg();

    error = setpoint - feedback;

    dbg_pid_setpoint_deg = setpoint;
    dbg_pid_feedback_deg = feedback;
    dbg_pid_error_deg = error;

    /*
       If position is inside deadband, stop PID position part.
       Torque term also becomes zero here for safety.
    */
    if (abs_float(error) <= PID_DEADBAND_DEG)
    {
        integral = 0.0f;
        error_prev = error;
        feedback_prev = feedback;
        velocity_prev = 0.0f;

        dbg_pid_up = 0.0f;
        dbg_pid_ui = 0.0f;
        dbg_pid_ud = 0.0f;
        dbg_pid_ut = 0.0f;
        dbg_pid_um = 0.0f;

        dbg_pid_output = 0.0f;
        dbg_pid_pwm_percent = 0.0f;
        dbg_pid_direction = 0u;
        dbg_pid_active = 0u;

        motor_app_stop();

        breakpoint_after_pid_update();
        return;
    }

    /*
       P term.
    */
    u_p = PID_KP * error;

    /*
       I term.
       KI is 0 right now, but this is ready.
    */
    integral += error * PID_DT_SEC;
    u_i = PID_KI * integral;

    /*
       D term.
       KD is 0 right now, but this is ready.
    */
    u_d = PID_KD * ((error - error_prev) / PID_DT_SEC);

    /*
       Torque term.
       torque_app gives centered torque value:
       0 at mid voltage.
    */
    torque_value = torque_app_get_value();

    u_t = PID_KT * torque_value * (float)PID_TORQUE_SIGN;

    /*
       Acceleration term.
       KM is 0 for now.
    */
    velocity = (feedback - feedback_prev) / PID_DT_SEC;
    acceleration = (velocity - velocity_prev) / PID_DT_SEC;

    u_m = PID_KM * acceleration;

    /*
       Total output.
    */
    output = u_p + u_i + u_d + u_t + u_m;

    /*
       If direction is wrong overall, flip PID_MOTOR_SIGN in config.h.
    */
    output = output * (float)PID_MOTOR_SIGN;

    output = clamp_float(output, -PID_MAX_PWM_PERCENT, PID_MAX_PWM_PERCENT);

    pwm_percent = abs_float(output);

    if (pwm_percent < PID_MIN_PWM_PERCENT)
    {
        pwm_percent = PID_MIN_PWM_PERCENT;
    }

    error_prev = error;
    feedback_prev = feedback;
    velocity_prev = velocity;

    dbg_pid_up = u_p;
    dbg_pid_ui = u_i;
    dbg_pid_ud = u_d;
    dbg_pid_ut = u_t;
    dbg_pid_um = u_m;

    dbg_pid_output = output;
    dbg_pid_pwm_percent = pwm_percent;
    dbg_pid_active = 1u;

    if (output > 0.0f)
    {
        dbg_pid_direction = 1u;
        motor_app_forward((uint8_t)pwm_percent);
    }
    else
    {
        dbg_pid_direction = 2u;
        motor_app_reverse((uint8_t)pwm_percent);
    }

    breakpoint_after_pid_update();
}