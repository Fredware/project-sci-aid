#ifndef ENCODER_APP_H
#define ENCODER_APP_H

#include "config.h"

void encoder_app_init(void);
void encoder_app_update(void);

uint16_t encoder_app_get_raw(void);
float encoder_app_get_deg(void);

#endif