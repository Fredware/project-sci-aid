#ifndef DEBUG_VARS_H
#define DEBUG_VARS_H

#include <stdint.h>

/* ============================================================
   CLOCK DEBUG
   ============================================================ */

extern volatile uint32_t dbg_cpu_clock_hz;
extern volatile uint32_t dbg_clock_ok;
extern volatile uint32_t dbg_slow_clock_enabled;

extern volatile uint32_t dbg_PMC_MCKR;
extern volatile uint32_t dbg_CKGR_MOR;
extern volatile uint32_t dbg_PMC_SR;
extern volatile uint32_t dbg_SUPC_SR;

extern volatile uint32_t dbg_ms;

/* ============================================================
   SLAVE 1 LOOP
   ============================================================ */

extern volatile uint32_t dbg_slave1_loop_count;

/* ============================================================
   I2C RECEIVE FROM MASTER
   ============================================================ */

extern volatile uint32_t dbg_valid_packet_count;
extern volatile uint32_t dbg_bad_packet_count;

extern volatile uint8_t  dbg_last_rx_byte;
extern volatile uint8_t  dbg_last_profile;
extern volatile uint8_t  dbg_last_position;
extern volatile uint8_t  dbg_link_good;

extern volatile uint32_t dbg_last_twi0_sr;

/* ============================================================
   ENCODER DEBUG
   ============================================================ */

extern volatile uint16_t dbg_encoder_raw;
extern volatile float    dbg_encoder_deg;
extern volatile float    dbg_flex_ext_deg;

extern volatile uint32_t dbg_encoder_read_count;
extern volatile uint8_t  dbg_encoder_ok;
extern volatile uint32_t dbg_last_twi5_sr;

/* ============================================================
   MOTOR DEBUG
   ============================================================ */

extern volatile uint8_t  dbg_motor_state;
/*
   0 = stop
   1 = forward
   2 = reverse
*/

extern volatile uint8_t  dbg_motor_dir_level;
extern volatile uint8_t  dbg_commanded_pwm_percent;
extern volatile uint32_t dbg_motor_test_step;
extern volatile uint32_t dbg_motor_test_step_start_ms;
extern volatile uint32_t dbg_tc0_rc;
extern volatile uint32_t dbg_tc0_ra;

/* ============================================================
   PID DEBUG
   ============================================================ */

extern volatile float    dbg_pid_setpoint_deg;
extern volatile float    dbg_pid_feedback_deg;
extern volatile float    dbg_pid_error_deg;

extern volatile float    dbg_pid_up;
extern volatile float    dbg_pid_ui;
extern volatile float    dbg_pid_ud;
extern volatile float    dbg_pid_ut;
extern volatile float    dbg_pid_um;

extern volatile float    dbg_pid_output;
extern volatile float    dbg_pid_pwm_percent;
extern volatile uint8_t  dbg_pid_direction;
extern volatile uint8_t  dbg_pid_active;

/* ============================================================
   TORQUE SENSOR DEBUG
   ============================================================ */

extern volatile uint16_t dbg_torque_adc;
extern volatile float    dbg_torque_voltage;
extern volatile float    dbg_torque_centered_voltage;
extern volatile float    dbg_torque_value;

/* ============================================================
   BREAKPOINT HELPERS
   ============================================================ */

void breakpoint_after_rx(void);
void breakpoint_after_encoder_read(void);
void breakpoint_after_motor_update(void);
void breakpoint_after_pid_update(void);
void breakpoint_after_torque_update(void);

#endif