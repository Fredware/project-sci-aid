#ifndef PID_APP_H
#define PID_APP_H

#include "config.h"

void pid_app_init(void);
void pid_app_update(void);

float pid_app_get_setpoint(void);

#endif