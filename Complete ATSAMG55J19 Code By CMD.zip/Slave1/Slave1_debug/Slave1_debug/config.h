#ifndef CONFIG_H
#define CONFIG_H

#include "sam.h"
#include <stdint.h>
#include <stdbool.h>

/* ============================================================
   CLOCK
   ============================================================ */

#define CPU_CLOCK_HZ                16000000u
#define SLOW_CLOCK_HZ               32768u

/* ============================================================
   SLAVE 1 I2C FROM MASTER
   PA9  = SCL
   PA10 = SDA
   Slave 1 address = 0x20
   ============================================================ */

#define MY_I2C_ADDR                 0x20u

#define BUS_I2C_SCL                 PIO_PA9
#define BUS_I2C_SDA                 PIO_PA10

#ifndef ID_FLEXCOM0
#define ID_FLEXCOM0                 19u
#endif

#ifndef FLEX_MR_OPMODE_TWI
#define FLEX_MR_OPMODE_TWI          3u
#endif

/* ============================================================
   COMMAND DEFINITIONS
   Master sends: cmd = profile * 2 + position
   ============================================================ */

#define NUM_PROFILES                3u

#define POS_A                       0u
#define POS_B                       1u

/* ============================================================
   ENCODER I2C
   PA12 = SCL
   PA13 = SDA
   ============================================================ */

#define ENCODER_I2C_SCL             PIO_PA12
#define ENCODER_I2C_SDA             PIO_PA13

#define ENCODER_ADDRESS             0x36u
#define ANGLE_REGISTER_ADDRESS      0x0Eu
#define ENCODER_COUNTS              4096.0f

#ifndef ID_FLEXCOM5
#define ID_FLEXCOM5                 24u
#endif

/* ============================================================
   FLEXION / EXTENSION CALIBRATION

   Down   raw = 553   -> -100 deg
   Middle raw = 1837  -> 0 deg
   Up     raw = 2707  -> +100 deg
   ============================================================ */

#define FLEX_DOWN_RAW               553.0f
#define FLEX_MID_RAW                1837.0f
#define FLEX_UP_RAW                 2707.0f

#define FLEX_DOWN_DEG               -100.0f
#define FLEX_MID_DEG                0.0f
#define FLEX_UP_DEG                 100.0f

/* ============================================================
   SLAVE 1 MOTOR PINS
   PA0  = PWM
   PA30 = DIR
   PB14 = BRAKE
   PB15 = nSLEEP
   ============================================================ */

#define M1_PWM_PIN                  PIO_PA0
#define M1_DIR_PIN                  PIO_PA30
#define M1_BRK_PIN                  PIO_PB14
#define NSLEEP_PIN                  PIO_PB15

#define LED1_PIN                    PIO_PA14
#define LED2_PIN                    PIO_PA11

#ifndef ID_TC0
#define ID_TC0                      23u
#endif

#define PWM_FREQ_HZ                 20000u
#define MOTOR_TEST_PWM_PERCENT      80u
#define MOTOR_TEST_RUN_MS           2000u
#define MOTOR_TEST_STOP_MS          1000u

#define BRAKE_RELEASE_LEVEL         0u
#define BRAKE_ACTIVE_LEVEL          1u

#define NSLEEP_WAKE_LEVEL           1u
#define NSLEEP_SLEEP_LEVEL          0u

/* ============================================================
   PID STARTING SETTINGS
   Safe low power first
   ============================================================ */

#define PID_KP                      035.0f
#define PID_KI                      0.0f
#define PID_KD                      02.0f

#define PID_DEADBAND_DEG            3.0f
#define PID_MAX_PWM_PERCENT         35.0f
#define PID_MIN_PWM_PERCENT         02.0f

/*
   If motor moves away from target, change this from 1 to -1.
*/
#define PID_MOTOR_SIGN              -1

/* ============================================================
   PROFILE SETPOINTS
   Position 0 = negative angle
   Position 1 = positive angle
   ============================================================ */

#define PROFILE0_POS0_DEG           -30.0f
#define PROFILE0_POS1_DEG            30.0f

#define PROFILE1_POS0_DEG           -60.0f
#define PROFILE1_POS1_DEG            60.0f

#define PROFILE2_POS0_DEG           -90.0f
#define PROFILE2_POS1_DEG            90.0f

/* ============================================================
   TORQUE SENSOR / HAL SENSOR

   HAL_SENSE from op-amp output.

   Suggested:
   PA19 = ADC channel 2

   Mid voltage center:
   1.65 V = zero torque
   Above 1.65 V = one torque direction
   Below 1.65 V = other torque direction

   No software filter.
   No software slew limit.
   No software output limit.
   PCB op-amp already handles analog gain/filter.
   ============================================================ */

#define TORQUE_SENSOR_ADC_PIN       PIO_PB5
#define TORQUE_SENSOR_ADC_CH        5u

#define TORQUE_ADC_REF_VOLTAGE      3.30f
#define TORQUE_ADC_MAX_COUNT        4095.0f

#define TORQUE_MID_VOLTAGE          0.730f
#define TORQUE_DEADBAND_VOLT        0.000f
#define TORQUE_SCALE                0.10f

/* ============================================================
   PID TORQUE SETTINGS
   ============================================================ */

#define PID_DT_SEC                  0.010f

/*
   Torque term gain.
   Start low first.
*/
#define PID_KT                      80000.0f

/*
   Acceleration term.
   Keep 0 for now.
*/
#define PID_KM                      0.0f

/*
   If torque sensor helps wrong direction, change this to -1.
*/
#define PID_TORQUE_SIGN             1
#endif